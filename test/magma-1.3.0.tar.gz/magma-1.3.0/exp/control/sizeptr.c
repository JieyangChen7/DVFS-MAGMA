#include <stdlib.h>
#include <stdio.h>

int main (){

  printf("%lu", sizeof(void *));

  return EXIT_SUCCESS;
}
