#ifndef MANGLING_H
#define MANGLING_H

/* Empty file. See magma_mangling.h
 * When using CMake, this gets replaced by Fortran name mangling. */

#endif        //  #ifndef MANGLING_H
