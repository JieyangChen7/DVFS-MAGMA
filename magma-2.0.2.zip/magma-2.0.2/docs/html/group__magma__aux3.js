var group__magma__aux3 =
[
    [ "single precision", "group__magma__saux3.html", "group__magma__saux3" ],
    [ "double precision", "group__magma__daux3.html", "group__magma__daux3" ],
    [ "single-complex precision", "group__magma__caux3.html", "group__magma__caux3" ],
    [ "double-complex precision", "group__magma__zaux3.html", "group__magma__zaux3" ]
];