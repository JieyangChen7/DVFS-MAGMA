var group__magma__zheev__driver =
[
    [ "magma_zheevd", "group__magma__zheev__driver.html#ga623139c7a079fff5dad908a51b6085a4", null ],
    [ "magma_zheevd_gpu", "group__magma__zheev__driver.html#ga841519bd19ba04630758ffda31bc1cbb", null ],
    [ "magma_zheevd_m", "group__magma__zheev__driver.html#ga61045f0f4962bb37a86096227848e5b8", null ],
    [ "magma_zheevdx", "group__magma__zheev__driver.html#ga4647f1ca5481e78f2c9f3248432347c0", null ],
    [ "magma_zheevdx_gpu", "group__magma__zheev__driver.html#ga3e6353330385d059dc7158813c9e6ffc", null ],
    [ "magma_zheevdx_m", "group__magma__zheev__driver.html#ga2ef0d19dad6a7ea4bc1d2c3ab7e1d80e", null ],
    [ "magma_zheevr", "group__magma__zheev__driver.html#gad13a22d9b91126f8a049ecba2026f2ae", null ],
    [ "magma_zheevr_gpu", "group__magma__zheev__driver.html#gae13bb322dc89a67187bc40ae05dd187d", null ],
    [ "magma_zheevx", "group__magma__zheev__driver.html#gaf52eba70bf6a90108c381ca50e75b3f8", null ],
    [ "magma_zheevx_gpu", "group__magma__zheev__driver.html#ga93603e49e26f7102780e022cb513bd62", null ]
];