var group__magma__sgeqp3__comp =
[
    [ "magma_sgeqp3", "group__magma__sgeqp3__comp.html#gaf6c2c2eb3d263d69fa961a389f4acd98", null ],
    [ "magma_sgeqp3_gpu", "group__magma__sgeqp3__comp.html#gaf2224d9941c9d313a2683b0e9b6a0113", null ]
];