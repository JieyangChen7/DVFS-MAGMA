var group__magma__posv__comp =
[
    [ "single precision", "group__magma__sposv__comp.html", "group__magma__sposv__comp" ],
    [ "double precision", "group__magma__dposv__comp.html", "group__magma__dposv__comp" ],
    [ "single-complex precision", "group__magma__cposv__comp.html", "group__magma__cposv__comp" ],
    [ "double-complex precision", "group__magma__zposv__comp.html", "group__magma__zposv__comp" ]
];