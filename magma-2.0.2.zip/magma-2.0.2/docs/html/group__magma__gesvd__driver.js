var group__magma__gesvd__driver =
[
    [ "single precision", "group__magma__sgesvd__driver.html", "group__magma__sgesvd__driver" ],
    [ "double precision", "group__magma__dgesvd__driver.html", "group__magma__dgesvd__driver" ],
    [ "single-complex precision", "group__magma__cgesvd__driver.html", "group__magma__cgesvd__driver" ],
    [ "double-complex precision", "group__magma__zgesvd__driver.html", "group__magma__zgesvd__driver" ]
];