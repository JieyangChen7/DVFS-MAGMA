var group__magma__cheev__2stage =
[
    [ "magma_chetrd_hb2st", "group__magma__cheev__2stage.html#gaf1fbb492481698e1b442c886c94fbb06", null ],
    [ "magma_chetrd_he2hb", "group__magma__cheev__2stage.html#ga8669e0f9380c40e07277cfec5bf57af1", null ],
    [ "magma_chetrd_he2hb_mgpu", "group__magma__cheev__2stage.html#ga684b9066d3dfae166ad81f8ea48fabf3", null ],
    [ "magma_cungqr_2stage_gpu", "group__magma__cheev__2stage.html#ga3bac95ab48acfac1f425c6c8870ee322", null ],
    [ "magma_cunmqr_gpu_2stages", "group__magma__cheev__2stage.html#ga4cdf2ca840d71f63ac0379de07422138", null ]
];