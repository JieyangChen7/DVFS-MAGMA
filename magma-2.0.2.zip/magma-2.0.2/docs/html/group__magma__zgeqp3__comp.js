var group__magma__zgeqp3__comp =
[
    [ "magma_zgeqp3", "group__magma__zgeqp3__comp.html#gacc2058c3bb2e1e2bc8b4685a2712c233", null ],
    [ "magma_zgeqp3_gpu", "group__magma__zgeqp3__comp.html#gadb379a9a11e952946db80f7e2c87959b", null ]
];