var group__magma__zsysv__comp =
[
    [ "magma_zsytrf_nopiv_gpu", "group__magma__zsysv__comp.html#ga59e9adcc6d87d40aba7762b31a4a7608", null ],
    [ "magma_zsytrs_nopiv_gpu", "group__magma__zsysv__comp.html#gaad8a257c5b6003e0f2fd5c4f226f1647", null ]
];