var group__magma__saux3 =
[
    [ "magma_slarfb_gemm_batched", "group__magma__saux3.html#gaab0f59aa35cc4d7906067d68a5b6dd82", null ],
    [ "magma_slarfb_gpu", "group__magma__saux3.html#ga475a4ccd8f6b09af1328a22609b2172d", null ],
    [ "magma_slarfb_gpu_gemm", "group__magma__saux3.html#ga3328c49a1f582f8f7b44805a3216db4b", null ],
    [ "magma_slarfb_gpu_gemm_q", "group__magma__saux3.html#gaca6ac8a8f9e4f48dcbff7fbc2d0fe755", null ],
    [ "magma_slarfb_gpu_q", "group__magma__saux3.html#ga5351cba030e7a13d22c52a558b1dfa44", null ],
    [ "magma_slarfbx_gpu", "group__magma__saux3.html#gaf0ada3a31ddcd2a2f7dabfb0d002cf61", null ],
    [ "magma_slarfy", "group__magma__saux3.html#ga70f69ba7e11bbbe8d5a15f9342ff15a0", null ]
];