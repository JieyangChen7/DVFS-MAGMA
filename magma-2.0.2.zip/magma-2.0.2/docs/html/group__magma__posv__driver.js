var group__magma__posv__driver =
[
    [ "single precision", "group__magma__sposv__driver.html", "group__magma__sposv__driver" ],
    [ "double precision", "group__magma__dposv__driver.html", "group__magma__dposv__driver" ],
    [ "single-complex precision", "group__magma__cposv__driver.html", "group__magma__cposv__driver" ],
    [ "double-complex precision", "group__magma__zposv__driver.html", "group__magma__zposv__driver" ]
];