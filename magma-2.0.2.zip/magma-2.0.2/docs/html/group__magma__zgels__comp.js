var group__magma__zgels__comp =
[
    [ "magma_zgeqrs3_gpu", "group__magma__zgels__comp.html#ga18688208aee9ee3c05dcc91f17508509", null ],
    [ "magma_zgeqrs_gpu", "group__magma__zgels__comp.html#ga54129b4952b03eddc4d86ce655d1d461", null ]
];