var group__magma__cgelqf__comp =
[
    [ "magma_cgelqf", "group__magma__cgelqf__comp.html#gae57eccef9401979dcc31e7d19d489b65", null ],
    [ "magma_cgelqf_gpu", "group__magma__cgelqf__comp.html#gaaa8519d360ee878aed30f7510ddc3634", null ],
    [ "magma_cunglq", "group__magma__cgelqf__comp.html#ga09dc5a9a998e87d2b165cd1b46cef75b", null ],
    [ "magma_cunmlq", "group__magma__cgelqf__comp.html#gaad2e8ada7d325dc80eede8a92bb51a53", null ]
];