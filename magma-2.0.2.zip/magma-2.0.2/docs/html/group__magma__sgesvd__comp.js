var group__magma__sgesvd__comp =
[
    [ "magma_sgebrd", "group__magma__sgesvd__comp.html#ga7d79e86a002ca0546e1d6844f408796d", null ],
    [ "magma_sorgbr", "group__magma__sgesvd__comp.html#gaa38931ac70cf3234915215fcae1db3b0", null ],
    [ "magma_sormbr", "group__magma__sgesvd__comp.html#gac37b5799828a34d2bb8c5c09fdc52b51", null ]
];