var group__magma__cgesv__aux =
[
    [ "magma_cgetf2_batched", "group__magma__cgesv__aux.html#ga8cc3d08f5a67e967f5e5eeb0b420a0f0", null ],
    [ "magma_cgetf2_nopiv", "group__magma__cgesv__aux.html#ga1df41454f3437f0148383b378b681a5d", null ],
    [ "magma_cgetf2_nopiv_batched", "group__magma__cgesv__aux.html#gac1c725fb4775183d56ae90a036b2fa28", null ]
];