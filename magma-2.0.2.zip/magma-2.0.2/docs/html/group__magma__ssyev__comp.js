var group__magma__ssyev__comp =
[
    [ "magma_sorgtr", "group__magma__ssyev__comp.html#ga3e667ca91073ae8e36a86b11bb879974", null ],
    [ "magma_sormtr", "group__magma__ssyev__comp.html#gaa1ea4a4a50f0ed126f64dde83f3aadb1", null ],
    [ "magma_sormtr_gpu", "group__magma__ssyev__comp.html#ga0b71c256fb40cc79ccbbe59c73b5ae6f", null ],
    [ "magma_sormtr_m", "group__magma__ssyev__comp.html#gae9553a071eeec8db772d7f86340cab23", null ],
    [ "magma_sstedx", "group__magma__ssyev__comp.html#gae951ed98bb3c1d1eb9deb37d6f1a0828", null ],
    [ "magma_sstedx_m", "group__magma__ssyev__comp.html#ga343ee9238e83e14eae09e6461733278e", null ],
    [ "magma_ssygst", "group__magma__ssyev__comp.html#ga2927c21de2f6714285435786526151b2", null ],
    [ "magma_ssygst_gpu", "group__magma__ssyev__comp.html#gaab615252287799490f12d0594b0b3945", null ],
    [ "magma_ssygst_m", "group__magma__ssyev__comp.html#ga20f9aedc1b55119bfe50f403083d1571", null ],
    [ "magma_ssytrd", "group__magma__ssyev__comp.html#ga0927a81947bfad9598baa1725b319696", null ],
    [ "magma_ssytrd2_gpu", "group__magma__ssyev__comp.html#ga5042f182deb4a5e27e6ac589fe6ad5c1", null ],
    [ "magma_ssytrd_gpu", "group__magma__ssyev__comp.html#ga016cdd7ea787eda56021dcbe3dae6569", null ],
    [ "magma_ssytrd_mgpu", "group__magma__ssyev__comp.html#ga27230476f0a617b9d9236d015cdb25a6", null ]
];