var group__magma__gesv__comp =
[
    [ "single precision", "group__magma__sgesv__comp.html", "group__magma__sgesv__comp" ],
    [ "double precision", "group__magma__dgesv__comp.html", "group__magma__dgesv__comp" ],
    [ "single-complex precision", "group__magma__cgesv__comp.html", "group__magma__cgesv__comp" ],
    [ "double-complex precision", "group__magma__zgesv__comp.html", "group__magma__zgesv__comp" ]
];