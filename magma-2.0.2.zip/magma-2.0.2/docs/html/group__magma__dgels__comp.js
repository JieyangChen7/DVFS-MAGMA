var group__magma__dgels__comp =
[
    [ "magma_dgeqrs3_gpu", "group__magma__dgels__comp.html#gad005707b6e39bf0265be0775c68fe23a", null ],
    [ "magma_dgeqrs_gpu", "group__magma__dgels__comp.html#ga1d734dcfbb55821744974a894ad16cf6", null ]
];