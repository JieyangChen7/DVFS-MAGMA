var group__magma__dsysv__comp =
[
    [ "magma_dsytrf", "group__magma__dsysv__comp.html#ga56cc086c875d638aed8ac10426bcfa08", null ],
    [ "magma_dsytrf_aasen", "group__magma__dsysv__comp.html#ga3cc6f4e8d6dd3133518b80d7dea9d49c", null ],
    [ "magma_dsytrf_nopiv", "group__magma__dsysv__comp.html#ga7623b865f5e9d8e3442ce7980774105b", null ],
    [ "magma_dsytrf_nopiv_gpu", "group__magma__dsysv__comp.html#ga8c6de43b0435d1a539a3f8da2cafb141", null ],
    [ "magma_dsytrs_nopiv_gpu", "group__magma__dsysv__comp.html#ga46bbdea68d8daad616f326bd4937331c", null ]
];