var group__magma__dsyev__aux =
[
    [ "magma_dlaex0", "group__magma__dsyev__aux.html#gad29318916a94d3d5a84fe9263027fedc", null ],
    [ "magma_dlaex0_m", "group__magma__dsyev__aux.html#ga9d5c7f795fc75ab251735ff1cc6a6e48", null ],
    [ "magma_dlaex1", "group__magma__dsyev__aux.html#gadbb212d49583e0bc2daf9c3449a15657", null ],
    [ "magma_dlaex1_m", "group__magma__dsyev__aux.html#ga0e0da522cc667a22dbf3f957b46d50b7", null ],
    [ "magma_dlaex3", "group__magma__dsyev__aux.html#ga03fb434cea1a00e7c89ad2c230f25d20", null ],
    [ "magma_dlaex3_m", "group__magma__dsyev__aux.html#ga06932e6e64fda3cf86a829878004691b", null ],
    [ "magma_dlatrd", "group__magma__dsyev__aux.html#gaf9a466ef88643767bac3ceffe538dc09", null ],
    [ "magma_dlatrd2", "group__magma__dsyev__aux.html#ga10ecf9efcea00d60f21ef3523e6e4e4f", null ],
    [ "magma_dlatrd_mgpu", "group__magma__dsyev__aux.html#gad5feca7d5ff1dba4bc45c76c05083f43", null ]
];