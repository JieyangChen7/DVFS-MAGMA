var group__magma__chesv__aux =
[
    [ "magma_clahef_gpu", "group__magma__chesv__aux.html#ga94f0cfeffa661f66c4459fc1c03d8241", null ]
];