var group__magma__zgeqp3__aux =
[
    [ "magma_zlaqps", "group__magma__zgeqp3__aux.html#ga347c52f3478efcdfcaf65eedde260e47", null ],
    [ "magma_zlaqps_gpu", "group__magma__zgeqp3__aux.html#gaf25c9aebef98fddef12c0fdc91e3a10d", null ]
];