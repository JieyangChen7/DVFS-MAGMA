var group__magma__cgeqrf__aux =
[
    [ "magma_cgeqr2_gpu", "group__magma__cgeqrf__aux.html#ga3f32f9b3c2a2706c71f777386adf7eb5", null ],
    [ "magma_cgeqr2x2_gpu", "group__magma__cgeqrf__aux.html#ga05e45a030845c356a17a6ef0aa5db55b", null ],
    [ "magma_cgeqr2x3_gpu", "group__magma__cgeqrf__aux.html#ga9d6286d9434bbbcc93a4f4251dcfefa6", null ],
    [ "magma_cgeqr2x_gpu", "group__magma__cgeqrf__aux.html#gad439be13a175246e2bfb4d213e1194c8", null ]
];