var group__magma__zaux1 =
[
    [ "magma_zlarfg_gpu", "group__magma__zaux1.html#gacb6143d149ccef24087b18a651d62d46", null ],
    [ "magma_zlarfgtx_gpu", "group__magma__zaux1.html#gaa715b645e699341bae0bfca0b15550fc", null ],
    [ "magma_zlarfgx_gpu", "group__magma__zaux1.html#gac902487dcc553c1658123f75d456f1f2", null ],
    [ "magma_zlarfx_gpu", "group__magma__zaux1.html#gadbcc12e1749de81b84543e4051d5bdba", null ],
    [ "magmablas_zlarfg", "group__magma__zaux1.html#ga88b37e2ee59216570f3a804cc89aece1", null ]
];