var group__magma__cgeqp3__comp =
[
    [ "magma_cgeqp3", "group__magma__cgeqp3__comp.html#ga1aa131f17dae8f46a6397b1137570050", null ],
    [ "magma_cgeqp3_gpu", "group__magma__cgeqp3__comp.html#gac41eb6c743cc23380c79142e6dc658b0", null ]
];