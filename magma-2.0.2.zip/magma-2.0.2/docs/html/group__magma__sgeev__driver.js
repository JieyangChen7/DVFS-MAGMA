var group__magma__sgeev__driver =
[
    [ "magma_sgeev", "group__magma__sgeev__driver.html#gacada0b72002c6182316aefa8a32822dd", null ],
    [ "magma_sgeev_m", "group__magma__sgeev__driver.html#gac02f88e376ff05c352c149e80235099a", null ]
];