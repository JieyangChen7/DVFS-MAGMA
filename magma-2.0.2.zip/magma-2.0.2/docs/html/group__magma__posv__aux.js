var group__magma__posv__aux =
[
    [ "single precision", "group__magma__sposv__aux.html", "group__magma__sposv__aux" ],
    [ "double precision", "group__magma__dposv__aux.html", "group__magma__dposv__aux" ],
    [ "single-complex precision", "group__magma__cposv__aux.html", "group__magma__cposv__aux" ],
    [ "double-complex precision", "group__magma__zposv__aux.html", "group__magma__zposv__aux" ]
];