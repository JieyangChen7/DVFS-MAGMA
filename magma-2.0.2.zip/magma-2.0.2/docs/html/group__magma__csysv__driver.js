var group__magma__csysv__driver =
[
    [ "magma_csysv_nopiv_gpu", "group__magma__csysv__driver.html#ga89a04c803110d0c05f0af744ffe7ad64", null ]
];