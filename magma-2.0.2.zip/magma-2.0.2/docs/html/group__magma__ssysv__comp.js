var group__magma__ssysv__comp =
[
    [ "magma_ssytrf", "group__magma__ssysv__comp.html#gac35791cdbb100521b26bf4e6e6766130", null ],
    [ "magma_ssytrf_aasen", "group__magma__ssysv__comp.html#gac4ac22ffa6248ad8c0ad686241cd35e3", null ],
    [ "magma_ssytrf_nopiv", "group__magma__ssysv__comp.html#gaeb92bda467038e06c3ac3896911fb1ac", null ],
    [ "magma_ssytrf_nopiv_gpu", "group__magma__ssysv__comp.html#ga44722b4c108648dbe08040f4c0df30b3", null ],
    [ "magma_ssytrs_nopiv_gpu", "group__magma__ssysv__comp.html#ga5a7e421b4a3aad5873ab86495374b92f", null ]
];