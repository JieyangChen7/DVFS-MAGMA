var group__magma__sblas2 =
[
    [ "magma_sgemv", "group__magma__sblas2.html#gafc5b68600ac2cffd1d7bfdda1ecf338b", null ],
    [ "magma_sgemv_q", "group__magma__sblas2.html#ga4ab482f6744b9b69dfd9c37c402c0c8b", null ],
    [ "magma_sger", "group__magma__sblas2.html#ga85a8fb5e787e08a7da754b68c4c0a167", null ],
    [ "magma_sger_q", "group__magma__sblas2.html#ga162ca80ea2e177dc58a0aceffb73dc88", null ],
    [ "magma_ssymv", "group__magma__sblas2.html#ga71f6de60d030b0f4acf80fd4e108b6e1", null ],
    [ "magma_ssymv_q", "group__magma__sblas2.html#gab689e5f4896b47e24e8625ba1e7e415b", null ],
    [ "magma_ssyr", "group__magma__sblas2.html#gab1877e646259c752bd2db97f7f05e899", null ],
    [ "magma_ssyr2", "group__magma__sblas2.html#gaa9b00a3a5087f2029381a0420dbdd6d1", null ],
    [ "magma_ssyr2_q", "group__magma__sblas2.html#gacdf47ec94842cfa8b1185aa097d8ba03", null ],
    [ "magma_ssyr_q", "group__magma__sblas2.html#ga393508709dfa70ddc4712e5ac57b732d", null ],
    [ "magma_strmv", "group__magma__sblas2.html#ga74a861d573ee77ce51adefa3da7ab08d", null ],
    [ "magma_strmv_q", "group__magma__sblas2.html#gab950192639bf789994d104c4d587dde8", null ],
    [ "magma_strsv", "group__magma__sblas2.html#ga02e63112e2fabb15f7b3262bee2fb48c", null ],
    [ "magma_strsv_q", "group__magma__sblas2.html#ga64946e1f65e57d8294e370bc421cad6c", null ],
    [ "magmablas_sgemv", "group__magma__sblas2.html#gaec4b4e4e6393cfd781c44206624b78fc", null ],
    [ "magmablas_sgemv_conj", "group__magma__sblas2.html#gad3dcb12ce816f3d677305a8b4cec72f3", null ],
    [ "magmablas_sswapblk", "group__magma__sblas2.html#gae3a27bf2bb3cdd1ef58699d1c3459005", null ],
    [ "magmablas_ssymv", "group__magma__sblas2.html#gaba9cbcefff617e9f6ffd4404fbfa2e05", null ]
];