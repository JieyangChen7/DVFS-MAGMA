var group__magma__syev__comp =
[
    [ "single precision", "group__magma__ssyev__comp.html", "group__magma__ssyev__comp" ],
    [ "double precision", "group__magma__dsyev__comp.html", "group__magma__dsyev__comp" ],
    [ "single-complex precision", "group__magma__cheev__comp.html", "group__magma__cheev__comp" ],
    [ "double-complex precision", "group__magma__zheev__comp.html", "group__magma__zheev__comp" ]
];