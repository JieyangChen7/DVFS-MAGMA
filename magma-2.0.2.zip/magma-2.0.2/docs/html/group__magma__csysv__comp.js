var group__magma__csysv__comp =
[
    [ "magma_csytrf_nopiv_gpu", "group__magma__csysv__comp.html#ga1bf78ae7e20f85970b0a3ee30a083dd8", null ],
    [ "magma_csytrs_nopiv_gpu", "group__magma__csysv__comp.html#gaecf46d627603c37bfc22581f32223649", null ]
];