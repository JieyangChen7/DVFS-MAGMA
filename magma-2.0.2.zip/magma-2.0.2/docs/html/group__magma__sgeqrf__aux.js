var group__magma__sgeqrf__aux =
[
    [ "magma_sgeqr2_gpu", "group__magma__sgeqrf__aux.html#ga8266dd9b7a8f92c74b937a976e2f38b3", null ],
    [ "magma_sgeqr2x2_gpu", "group__magma__sgeqrf__aux.html#gaf6929650f515424ef12dfce00d5d593c", null ],
    [ "magma_sgeqr2x3_gpu", "group__magma__sgeqrf__aux.html#ga9538401329cc51e82aa51fb40f830685", null ],
    [ "magma_sgeqr2x_gpu", "group__magma__sgeqrf__aux.html#gaa3f8e963dfb6dc9c469385062badd753", null ]
];