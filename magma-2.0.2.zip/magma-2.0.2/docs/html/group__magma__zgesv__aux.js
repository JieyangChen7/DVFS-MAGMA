var group__magma__zgesv__aux =
[
    [ "magma_zgetf2_batched", "group__magma__zgesv__aux.html#gab1cccffa57aa2655f62e2d71820bab56", null ],
    [ "magma_zgetf2_nopiv", "group__magma__zgesv__aux.html#ga1cf9b1cc4394a5c9df433b5f33b6edb4", null ],
    [ "magma_zgetf2_nopiv_batched", "group__magma__zgesv__aux.html#ga476b42de33fa5aac2ca76f09d5c51d8a", null ]
];