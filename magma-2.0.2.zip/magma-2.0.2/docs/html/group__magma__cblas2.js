var group__magma__cblas2 =
[
    [ "magma_cgemv", "group__magma__cblas2.html#ga994fc0b360f4bae1a4f948b44e2c27ff", null ],
    [ "magma_cgemv_q", "group__magma__cblas2.html#ga52d7f99be9447cb3b82e6f51ac86839b", null ],
    [ "magma_cgerc", "group__magma__cblas2.html#gaa45b475cf05407d76c1c583200c4e897", null ],
    [ "magma_cgerc_q", "group__magma__cblas2.html#ga436796209226ecffbfadbf4e9c3821c6", null ],
    [ "magma_cgeru", "group__magma__cblas2.html#gad01faca0af950f3b0692dfd65c0baebd", null ],
    [ "magma_cgeru_q", "group__magma__cblas2.html#gaa8ab0f5a7c8fc4acccfea012dec4ab11", null ],
    [ "magma_chemv", "group__magma__cblas2.html#gac5914b9731fe8176ca70d2a889a5b8a7", null ],
    [ "magma_chemv_q", "group__magma__cblas2.html#gab0edbf0fcbb929afc158f9f590b268ed", null ],
    [ "magma_cher", "group__magma__cblas2.html#ga6c047906169c1fbfdb186ac8c98cb735", null ],
    [ "magma_cher2", "group__magma__cblas2.html#ga87e00aaaf9f6fd0f37e6f64bb0b1bd1a", null ],
    [ "magma_cher2_q", "group__magma__cblas2.html#ga4c8c3213d69481149ff39ab4f1e79d0a", null ],
    [ "magma_cher_q", "group__magma__cblas2.html#gab44807a48d1cddb489bbdbf04eb202a7", null ],
    [ "magma_ctrmv", "group__magma__cblas2.html#ga5a75a5da6b4934496bf8b5e70c9baf71", null ],
    [ "magma_ctrmv_q", "group__magma__cblas2.html#gae7ef10cb7c3e38c28d191b71e61fcdcb", null ],
    [ "magma_ctrsv", "group__magma__cblas2.html#gac27e0aa2d8985d99e176f9824175f0da", null ],
    [ "magma_ctrsv_q", "group__magma__cblas2.html#ga7fafa89ede8a410b65e056046d32ce09", null ],
    [ "magmablas_cgemv", "group__magma__cblas2.html#ga1fda941d65bbe2054266aad169e7daaa", null ],
    [ "magmablas_cgemv_conj", "group__magma__cblas2.html#ga2a875386c0a6e96d63a61645221a8f16", null ],
    [ "magmablas_chemv", "group__magma__cblas2.html#gafdad4368e39a9b9eaf623209b6e02f65", null ],
    [ "magmablas_cswapblk", "group__magma__cblas2.html#ga236bd01c8bf9819e2fdbb86a80578bc8", null ],
    [ "magmablas_csymv", "group__magma__cblas2.html#ga19d07f3afda57035926f0601435f3dc4", null ]
];