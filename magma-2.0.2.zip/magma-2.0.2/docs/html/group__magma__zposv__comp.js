var group__magma__zposv__comp =
[
    [ "magma_zpotrf", "group__magma__zposv__comp.html#ga54e1d2593c112d13b430650b1872eb2c", null ],
    [ "magma_zpotrf3_mgpu", "group__magma__zposv__comp.html#ga123bf118b2f8562076a64f57a9f945ad", null ],
    [ "magma_zpotrf_gpu", "group__magma__zposv__comp.html#ga8b3257063d4dca90fc64cd6709c4a7dd", null ],
    [ "magma_zpotrf_lg_batched", "group__magma__zposv__comp.html#ga34a586ce14ea5cd95b032ffa5de1893c", null ],
    [ "magma_zpotrf_m", "group__magma__zposv__comp.html#gae4e9f7e8272cb75031524671c277be8c", null ],
    [ "magma_zpotrf_mgpu", "group__magma__zposv__comp.html#ga18c57d9b673a6f87cc01f9d22e37d61c", null ],
    [ "magma_zpotrf_mgpu_right", "group__magma__zposv__comp.html#ga58fa9644b488be64cd39aba6bc87f596", null ],
    [ "magma_zpotri", "group__magma__zposv__comp.html#gae2c12bee6bd4d6dee3b3c002aef0dcf1", null ],
    [ "magma_zpotri_gpu", "group__magma__zposv__comp.html#gaaa48028a79fe088631d2832c7b85fa73", null ],
    [ "magma_zpotrs_batched", "group__magma__zposv__comp.html#ga7ba860509604deb097b36140a2e67661", null ],
    [ "magma_zpotrs_gpu", "group__magma__zposv__comp.html#gaf7fe5a94d4667bb4b5246ee408201020", null ]
];