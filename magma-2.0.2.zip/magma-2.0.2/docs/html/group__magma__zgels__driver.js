var group__magma__zgels__driver =
[
    [ "magma_zcgeqrsv_gpu", "group__magma__zgels__driver.html#gaccc1efc3a9d3f9a97b565183efe98e2c", null ],
    [ "magma_zgels", "group__magma__zgels__driver.html#ga86eec437e948fd6b77c239933b111c33", null ],
    [ "magma_zgels3_gpu", "group__magma__zgels__driver.html#ga0f0bd53fa656ae45a231bb8bbba0feda", null ],
    [ "magma_zgels_gpu", "group__magma__zgels__driver.html#ga543dd53fccbce2c1bf3093fecd06b85c", null ]
];