var group__magma__dgeev__comp =
[
    [ "dtrevc3", "group__magma__dgeev__comp.html#ga22043a0e4e3976d5d3f3c009264caa5e", null ],
    [ "magma_dgehrd", "group__magma__dgeev__comp.html#ga1fc2286856068ada21e9c0f42222eedc", null ],
    [ "magma_dgehrd2", "group__magma__dgeev__comp.html#ga39856ecd9615bc1cfbc8321b01bc4da7", null ],
    [ "magma_dgehrd_m", "group__magma__dgeev__comp.html#ga6d63dca9db66dcfdbf6b487655016107", null ],
    [ "magma_dorghr", "group__magma__dgeev__comp.html#ga0e4bd531da2ce60ee0a59c59a46a8748", null ],
    [ "magma_dorghr_m", "group__magma__dgeev__comp.html#gacb04d6062459e58fc39d9add80c498d4", null ],
    [ "magma_dtrevc3", "group__magma__dgeev__comp.html#ga3ac9f2433592c0d319569bc477181267", null ],
    [ "magma_dtrevc3_mt", "group__magma__dgeev__comp.html#ga50f51280487b0ce62a08fed05b9e72df", null ]
];