var group__magma__dsyev__driver =
[
    [ "magma_dsyevd", "group__magma__dsyev__driver.html#ga649aa6cbaeb864d27d93d312a7f23ac4", null ],
    [ "magma_dsyevd_gpu", "group__magma__dsyev__driver.html#gac8e90527f61303735140faaa4de1f74b", null ],
    [ "magma_dsyevd_m", "group__magma__dsyev__driver.html#gaa996c795c741ec5144dd814ffe68a9eb", null ],
    [ "magma_dsyevdx", "group__magma__dsyev__driver.html#ga6c1976084df6610b3ed341606aab281e", null ],
    [ "magma_dsyevdx_gpu", "group__magma__dsyev__driver.html#ga3d9f19bbb092227e42fa779b45a3cc34", null ],
    [ "magma_dsyevdx_m", "group__magma__dsyev__driver.html#gaa86541de8643d5f3b1a79c8208e83f37", null ]
];