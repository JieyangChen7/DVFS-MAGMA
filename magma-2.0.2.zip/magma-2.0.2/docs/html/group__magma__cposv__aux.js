var group__magma__cposv__aux =
[
    [ "magma_clauum", "group__magma__cposv__aux.html#gad405cca6bb5c7ce28413a1660ec04b36", null ],
    [ "magma_clauum_gpu", "group__magma__cposv__aux.html#ga0e9ea0912fff6ef3011218529243ed22", null ]
];