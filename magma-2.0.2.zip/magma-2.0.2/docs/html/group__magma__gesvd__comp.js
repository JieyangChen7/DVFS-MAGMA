var group__magma__gesvd__comp =
[
    [ "single precision", "group__magma__sgesvd__comp.html", "group__magma__sgesvd__comp" ],
    [ "double precision", "group__magma__dgesvd__comp.html", "group__magma__dgesvd__comp" ],
    [ "single-complex precision", "group__magma__cgesvd__comp.html", "group__magma__cgesvd__comp" ],
    [ "double-complex precision", "group__magma__zgesvd__comp.html", "group__magma__zgesvd__comp" ]
];