var group__magma__blas3 =
[
    [ "single precision", "group__magma__sblas3.html", "group__magma__sblas3" ],
    [ "double precision", "group__magma__dblas3.html", "group__magma__dblas3" ],
    [ "single-complex precision", "group__magma__cblas3.html", "group__magma__cblas3" ],
    [ "double-complex precision", "group__magma__zblas3.html", "group__magma__zblas3" ]
];