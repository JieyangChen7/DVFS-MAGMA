var group__magma__ssyev__2stage =
[
    [ "magma_sorgqr_2stage_gpu", "group__magma__ssyev__2stage.html#gaf6ada85afb6c96492f63a24252f925f5", null ],
    [ "magma_sormqr_gpu_2stages", "group__magma__ssyev__2stage.html#gaa585b531142b7698130d43932a3eeb7f", null ],
    [ "magma_ssytrd_sb2st", "group__magma__ssyev__2stage.html#ga057f6d45d44295c3af737620e9a0bf6f", null ],
    [ "magma_ssytrd_sy2sb", "group__magma__ssyev__2stage.html#ga06cd1e768e99e808935ed82db0abcbda", null ],
    [ "magma_ssytrd_sy2sb_mgpu", "group__magma__ssyev__2stage.html#ga0d9f22eb0293353a4fa8805c1977c5ee", null ]
];