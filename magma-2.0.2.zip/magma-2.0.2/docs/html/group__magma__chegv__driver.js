var group__magma__chegv__driver =
[
    [ "magma_chegvd", "group__magma__chegv__driver.html#gad455eca8b7ee4a27f6d24a4f2d2cd365", null ],
    [ "magma_chegvd_m", "group__magma__chegv__driver.html#gaabe5cc9e3cb435d595f4b3d2c56d3852", null ],
    [ "magma_chegvdx", "group__magma__chegv__driver.html#gace6c35961b96c751528c04c7d5e1ab93", null ],
    [ "magma_chegvdx_2stage", "group__magma__chegv__driver.html#ga72c1811f282dcff97d3946a422e54ec2", null ],
    [ "magma_chegvdx_2stage_m", "group__magma__chegv__driver.html#gab6e0bf9b75d033f596e9b16b80af015a", null ],
    [ "magma_chegvdx_m", "group__magma__chegv__driver.html#gab2379b920dde12ef5d5cba5da0abceea", null ],
    [ "magma_chegvr", "group__magma__chegv__driver.html#ga573482f53abcc541cc370c32e0af3f45", null ],
    [ "magma_chegvx", "group__magma__chegv__driver.html#ga6516dd2c3a5c299c1b2f4381d5cf3eb3", null ]
];