var group__magma__cgels__comp =
[
    [ "magma_cgeqrs3_gpu", "group__magma__cgels__comp.html#gad3f5469fe930167f47a2445a8a44a523", null ],
    [ "magma_cgeqrs_gpu", "group__magma__cgels__comp.html#ga1d5068bb21175de5241427676dc3aa75", null ]
];