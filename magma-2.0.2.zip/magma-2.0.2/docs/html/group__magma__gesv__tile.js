var group__magma__gesv__tile =
[
    [ "single precision", "group__magma__sgesv__tile.html", null ],
    [ "double precision", "group__magma__dgesv__tile.html", null ],
    [ "single-complex precision", "group__magma__cgesv__tile.html", null ],
    [ "double-complex precision", "group__magma__zgesv__tile.html", null ]
];