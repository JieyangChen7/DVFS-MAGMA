var group___b_l_a_s =
[
    [ "Level-1 BLAS", "group__magma__blas1.html", "group__magma__blas1" ],
    [ "Level-2 BLAS", "group__magma__blas2.html", "group__magma__blas2" ],
    [ "Level-3 BLAS", "group__magma__blas3.html", "group__magma__blas3" ],
    [ "Math auxiliary", "group__magma__aux0.html", "group__magma__aux0" ],
    [ "Level-1 auxiliary", "group__magma__aux1.html", "group__magma__aux1" ],
    [ "Level-2 auxiliary", "group__magma__aux2.html", "group__magma__aux2" ],
    [ "Level-3 auxiliary", "group__magma__aux3.html", "group__magma__aux3" ]
];