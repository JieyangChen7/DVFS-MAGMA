var group__magma__zgeqrf__comp =
[
    [ "magma_zgegqr_gpu", "group__magma__zgeqrf__comp.html#ga72e995bd49d2cdc8bdd94cb247b63386", null ],
    [ "magma_zgeqrf", "group__magma__zgeqrf__comp.html#ga204d1e33825ec70fe68ac07187039800", null ],
    [ "magma_zgeqrf2_gpu", "group__magma__zgeqrf__comp.html#ga15d7cf0446dcf4657cf531ba92746525", null ],
    [ "magma_zgeqrf2_mgpu", "group__magma__zgeqrf__comp.html#ga517a6fa285754905600beaa32d650c78", null ],
    [ "magma_zgeqrf3_gpu", "group__magma__zgeqrf__comp.html#gab8fa0746f4d05679559141d33d04f0fe", null ],
    [ "magma_zgeqrf_batched", "group__magma__zgeqrf__comp.html#ga12bacf0973d98d012f8eb38f00d16f96", null ],
    [ "magma_zgeqrf_expert_batched", "group__magma__zgeqrf__comp.html#gab8099632f391f152464daba50927d117", null ],
    [ "magma_zgeqrf_gpu", "group__magma__zgeqrf__comp.html#ga8be3baf08856d86c56262e54e771f3fa", null ],
    [ "magma_zgeqrf_m", "group__magma__zgeqrf__comp.html#ga77f98c4ebd689860e4afa3b7cf342872", null ],
    [ "magma_zgeqrf_ooc", "group__magma__zgeqrf__comp.html#ga2c6667c239ed3f2f8aa76b6490c2db3d", null ],
    [ "magma_zungqr", "group__magma__zgeqrf__comp.html#gafe72e6255dc28171aacf72134f332aa4", null ],
    [ "magma_zungqr2", "group__magma__zgeqrf__comp.html#ga5c72df779157f898792065cbe4750ef3", null ],
    [ "magma_zungqr_gpu", "group__magma__zgeqrf__comp.html#ga94b013e5ea65faafa9d3470646f89482", null ],
    [ "magma_zungqr_m", "group__magma__zgeqrf__comp.html#ga9245d369e71d90882707ce22aa2490cd", null ],
    [ "magma_zunmqr", "group__magma__zgeqrf__comp.html#ga04caefefcecc9958e5a515584f09cf95", null ],
    [ "magma_zunmqr2_gpu", "group__magma__zgeqrf__comp.html#ga3219b09f44b990599efc32cbf986cef0", null ],
    [ "magma_zunmqr_gpu", "group__magma__zgeqrf__comp.html#ga129a01a7caecb681c244e484435deac5", null ],
    [ "magma_zunmqr_m", "group__magma__zgeqrf__comp.html#ga76cdee4665c9594ead67e719edc2db73", null ]
];