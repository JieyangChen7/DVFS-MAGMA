var group__magma__init =
[
    [ "magma_finalize", "group__magma__init.html#gae7463bee75a4c738929f1169b930938b", null ],
    [ "magma_init", "group__magma__init.html#ga7cc179c267eb6c5f154ffd40d4759ab3", null ],
    [ "magma_print_environment", "group__magma__init.html#gad4ab03f6f03a9a3ee635187b21317008", null ]
];