var group__magma__zgesvd__comp =
[
    [ "magma_zgebrd", "group__magma__zgesvd__comp.html#ga373b416c847e6bcfecc2c564b07a7777", null ],
    [ "magma_zungbr", "group__magma__zgesvd__comp.html#gaea8094b5bcfc3c534245923538aa28c8", null ],
    [ "magma_zunmbr", "group__magma__zgesvd__comp.html#ga13227babdef75e63eee758c32e9d9dfb", null ]
];