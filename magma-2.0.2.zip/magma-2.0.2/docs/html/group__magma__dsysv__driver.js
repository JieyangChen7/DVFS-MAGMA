var group__magma__dsysv__driver =
[
    [ "magma_dsysv", "group__magma__dsysv__driver.html#gafec06de40467b42037b0551038c6ac0c", null ],
    [ "magma_dsysv_nopiv_gpu", "group__magma__dsysv__driver.html#gabaddab46ebb469c008a0d8513a77ed07", null ]
];