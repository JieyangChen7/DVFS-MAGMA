var group__magma__geev__driver =
[
    [ "single precision", "group__magma__sgeev__driver.html", "group__magma__sgeev__driver" ],
    [ "double precision", "group__magma__dgeev__driver.html", "group__magma__dgeev__driver" ],
    [ "single-complex precision", "group__magma__cgeev__driver.html", "group__magma__cgeev__driver" ],
    [ "double-complex precision", "group__magma__zgeev__driver.html", "group__magma__zgeev__driver" ]
];