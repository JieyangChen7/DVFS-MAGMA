var group__magma__util =
[
    [ "cusparse2magma_error", "group__magma__util.html#gaf1a014b017dcd37c5157b89ac4c89200", null ],
    [ "magma_cmake_lwork", "group__magma__util.html#ga789db9b1e12386beddcd35698b27910d", null ],
    [ "magma_dmake_lwork", "group__magma__util.html#ga841c04d8ab72bd323d2dcb9374923ddf", null ],
    [ "magma_get_lapack_numthreads", "group__magma__util.html#ga6fc0af8a25c14a401e5c99d0f9471dc2", null ],
    [ "magma_get_omp_numthreads", "group__magma__util.html#gacdbde56a044ad34edc3cf57a50a9c0be", null ],
    [ "magma_get_parallel_numthreads", "group__magma__util.html#gad07446b16b26c7e36cc08e6601845460", null ],
    [ "magma_is_devptr", "group__magma__util.html#gae69c91a4a2093a4d3b5792208b03f75d", null ],
    [ "magma_set_lapack_numthreads", "group__magma__util.html#ga13335e97e234ce80485616788c42706f", null ],
    [ "magma_set_omp_numthreads", "group__magma__util.html#ga9f4fb8c940bfeb9d6c7cd7feae6ed433", null ],
    [ "magma_smake_lwork", "group__magma__util.html#ga636014f87919fe4a9411f520094ade51", null ],
    [ "magma_xerbla", "group__magma__util.html#ga7f61a6336b27c0f3ca235ba3f474bc90", null ],
    [ "magma_zmake_lwork", "group__magma__util.html#ga35c54504990bd942691e89f7a5884686", null ]
];