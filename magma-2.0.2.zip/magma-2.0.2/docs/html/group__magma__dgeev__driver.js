var group__magma__dgeev__driver =
[
    [ "magma_dgeev", "group__magma__dgeev__driver.html#gace6cb42b5d62631a35577df62d3b0544", null ],
    [ "magma_dgeev_m", "group__magma__dgeev__driver.html#ga2b468b99b54620161a578d25ce26fb82", null ]
];