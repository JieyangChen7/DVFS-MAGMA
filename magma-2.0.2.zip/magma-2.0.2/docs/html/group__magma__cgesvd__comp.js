var group__magma__cgesvd__comp =
[
    [ "magma_cgebrd", "group__magma__cgesvd__comp.html#gab2f1544a9f3a90b989c414c6d09f7301", null ],
    [ "magma_cungbr", "group__magma__cgesvd__comp.html#ga3c2217286969d167984e3f1d5cc27875", null ],
    [ "magma_cunmbr", "group__magma__cgesvd__comp.html#gafe068e8f0a2ebff10a7d19762d48b77f", null ]
];