var group__magma__cheev__comp =
[
    [ "magma_chegst", "group__magma__cheev__comp.html#ga36bdc329547b4127b61012335f0844a0", null ],
    [ "magma_chegst_gpu", "group__magma__cheev__comp.html#ga44180ddcf785d42793f0088a2cebb52c", null ],
    [ "magma_chegst_m", "group__magma__cheev__comp.html#gaa56ce9a5e5530a95c9414cc7e607757e", null ],
    [ "magma_chetrd", "group__magma__cheev__comp.html#ga9ea3b36bf46dc73b9640a4336a29ff8c", null ],
    [ "magma_chetrd2_gpu", "group__magma__cheev__comp.html#ga257b6e142174d0efd0d64a4982e8f3f2", null ],
    [ "magma_chetrd_gpu", "group__magma__cheev__comp.html#ga63a650baf86318bf0456223767d4383b", null ],
    [ "magma_chetrd_mgpu", "group__magma__cheev__comp.html#ga1df8ce07d784cad28c95038262705443", null ],
    [ "magma_cstedx", "group__magma__cheev__comp.html#gac0b418257d462b5007c7b4f5d3b6173c", null ],
    [ "magma_cstedx_m", "group__magma__cheev__comp.html#ga058fcc87790b6d51cf1f7d1cf32c5524", null ],
    [ "magma_cungtr", "group__magma__cheev__comp.html#gae643a52368c8d2afc08891356f019e86", null ],
    [ "magma_cunmtr", "group__magma__cheev__comp.html#gad50c2fac66780cac5185f58a2e53130e", null ],
    [ "magma_cunmtr_gpu", "group__magma__cheev__comp.html#gaa5b1eb7a52798ecdfacfd3d22c4669b1", null ],
    [ "magma_cunmtr_m", "group__magma__cheev__comp.html#ga09fc92bf4191da2db8e1f54462ea41ae", null ]
];