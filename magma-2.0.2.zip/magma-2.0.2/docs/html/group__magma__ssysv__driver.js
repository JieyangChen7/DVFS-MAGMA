var group__magma__ssysv__driver =
[
    [ "magma_ssysv", "group__magma__ssysv__driver.html#gaaf74ae877d855f6008bbd159a231033d", null ],
    [ "magma_ssysv_nopiv_gpu", "group__magma__ssysv__driver.html#ga22bb3707f4f59a660e44515cce47da7c", null ]
];