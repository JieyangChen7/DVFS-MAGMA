var group__magma__dgeev__aux =
[
    [ "magma_dlahr2", "group__magma__dgeev__aux.html#gad295f1824979bd337899b7ef539d6b23", null ],
    [ "magma_dlahr2_m", "group__magma__dgeev__aux.html#ga6ec257e844f955ff5aacf59644baebb1", null ],
    [ "magma_dlahru", "group__magma__dgeev__aux.html#ga409647f7f93a3c9ab2bffa2cd07281d5", null ],
    [ "magma_dlahru_m", "group__magma__dgeev__aux.html#ga87875d13ae8a627d597d9f17670c95ae", null ],
    [ "magma_dlaqtrsd", "group__magma__dgeev__aux.html#ga7b752e8002c82b03f7f4802227f83df3", null ]
];