var group__magma__dgelqf__comp =
[
    [ "magma_dgelqf", "group__magma__dgelqf__comp.html#gad4a269d7fadc9d0be588a603b3be2cc0", null ],
    [ "magma_dgelqf_gpu", "group__magma__dgelqf__comp.html#gaf5acffa6da260067b2ac7eb5a1106e2d", null ],
    [ "magma_dorglq", "group__magma__dgelqf__comp.html#ga7e2fecc6cf64eda76cd75ec199b992b2", null ],
    [ "magma_dormlq", "group__magma__dgelqf__comp.html#gac27b29f9406bc5d2fb574d55d5d51d88", null ]
];