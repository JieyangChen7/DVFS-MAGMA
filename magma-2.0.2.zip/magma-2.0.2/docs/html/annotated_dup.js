var annotated_dup =
[
    [ "magma_queue", "structmagma__queue.html", null ],
    [ "magma_thread_queue", "classmagma__thread__queue.html", "classmagma__thread__queue" ]
];