var group__magma__dgesv__aux =
[
    [ "magma_dgetf2_batched", "group__magma__dgesv__aux.html#gae556608afe6feb4b29d8f8450ce3e415", null ],
    [ "magma_dgetf2_nopiv", "group__magma__dgesv__aux.html#ga04c36e13a0823443c97641f9a9153cba", null ],
    [ "magma_dgetf2_nopiv_batched", "group__magma__dgesv__aux.html#ga9d08e20c5d67c11e6288a59f58be27d5", null ]
];