var group__magma__saux0 =
[
    [ "magma_slaln2", "group__magma__saux0.html#gab2e527122c07b12419330d4dd5ec5a28", null ]
];