var group__magma__caux0 =
[
    [ "magma_csqrt", "group__magma__caux0.html#gaa9bcaa60ffb9911877b912eb2a8519bb", null ]
];