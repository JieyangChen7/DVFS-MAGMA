var group__magma__sposv__aux =
[
    [ "magma_slauum", "group__magma__sposv__aux.html#ga28fbc613392982c3d30d4fdde5944728", null ],
    [ "magma_slauum_gpu", "group__magma__sposv__aux.html#ga96b57cc3eef093251307277439a7bd52", null ]
];