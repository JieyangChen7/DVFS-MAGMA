var group__magma__daux0 =
[
    [ "magma_dlaln2", "group__magma__daux0.html#ga88ec27c3e76cab2d6d3e9716107511db", null ]
];