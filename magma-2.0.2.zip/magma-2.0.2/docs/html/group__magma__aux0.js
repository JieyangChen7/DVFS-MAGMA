var group__magma__aux0 =
[
    [ "single precision", "group__magma__saux0.html", "group__magma__saux0" ],
    [ "double precision", "group__magma__daux0.html", "group__magma__daux0" ],
    [ "single-complex precision", "group__magma__caux0.html", "group__magma__caux0" ],
    [ "double-complex precision", "group__magma__zaux0.html", "group__magma__zaux0" ]
];