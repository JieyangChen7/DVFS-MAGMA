var group__magma__gels =
[
    [ "Least squares solve: driver", "group__magma__gels__driver.html", "group__magma__gels__driver" ],
    [ "Least squares solve: computational", "group__magma__gels__comp.html", "group__magma__gels__comp" ]
];