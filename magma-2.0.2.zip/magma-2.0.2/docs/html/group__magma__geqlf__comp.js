var group__magma__geqlf__comp =
[
    [ "single precision", "group__magma__sgeqlf__comp.html", "group__magma__sgeqlf__comp" ],
    [ "double precision", "group__magma__dgeqlf__comp.html", "group__magma__dgeqlf__comp" ],
    [ "single-complex precision", "group__magma__cgeqlf__comp.html", "group__magma__cgeqlf__comp" ],
    [ "double-complex precision", "group__magma__zgeqlf__comp.html", "group__magma__zgeqlf__comp" ]
];