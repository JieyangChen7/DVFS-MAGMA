var group__magma__geev__aux =
[
    [ "single precision", "group__magma__sgeev__aux.html", "group__magma__sgeev__aux" ],
    [ "double precision", "group__magma__dgeev__aux.html", "group__magma__dgeev__aux" ],
    [ "single-complex precision", "group__magma__cgeev__aux.html", "group__magma__cgeev__aux" ],
    [ "double-complex precision", "group__magma__zgeev__aux.html", "group__magma__zgeev__aux" ]
];