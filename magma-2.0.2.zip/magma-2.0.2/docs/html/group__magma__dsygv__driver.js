var group__magma__dsygv__driver =
[
    [ "magma_dsygvd", "group__magma__dsygv__driver.html#gaf9b4b71545eaeaec49142c25d652cd9f", null ],
    [ "magma_dsygvd_m", "group__magma__dsygv__driver.html#gae90e75f97ea4de24cf9ec6096d1e16e4", null ],
    [ "magma_dsygvdx", "group__magma__dsygv__driver.html#ga9ec1a222050544d3ae88a63cd8b44b47", null ],
    [ "magma_dsygvdx_m", "group__magma__dsygv__driver.html#gab80abc4a3e702c3269598a2c0c98b706", null ]
];