var group__magma__gels__driver =
[
    [ "single precision", "group__magma__sgels__driver.html", "group__magma__sgels__driver" ],
    [ "double precision", "group__magma__dgels__driver.html", "group__magma__dgels__driver" ],
    [ "single-complex precision", "group__magma__cgels__driver.html", "group__magma__cgels__driver" ],
    [ "double-complex precision", "group__magma__zgels__driver.html", "group__magma__zgels__driver" ]
];