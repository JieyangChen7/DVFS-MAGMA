var group__magma__dsyev__2stage =
[
    [ "magma_dorgqr_2stage_gpu", "group__magma__dsyev__2stage.html#ga542b306a28775d9342705497efa28dc2", null ],
    [ "magma_dormqr_gpu_2stages", "group__magma__dsyev__2stage.html#gad2694572886ccf12bcb7190b19679ce0", null ],
    [ "magma_dsytrd_sb2st", "group__magma__dsyev__2stage.html#ga327c759affbe1b30abb6eebdeb520c54", null ],
    [ "magma_dsytrd_sy2sb", "group__magma__dsyev__2stage.html#ga0c3ba88f70efd32ec7da0ee242a4a519", null ],
    [ "magma_dsytrd_sy2sb_mgpu", "group__magma__dsyev__2stage.html#ga6cf8bf79e38fcdb5292774bdd0f05614", null ]
];