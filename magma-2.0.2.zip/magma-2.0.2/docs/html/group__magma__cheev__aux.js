var group__magma__cheev__aux =
[
    [ "magma_clatrd", "group__magma__cheev__aux.html#gac5ad84ba02dfba5a27760f8de2f9bf14", null ],
    [ "magma_clatrd2", "group__magma__cheev__aux.html#gacf0727df95873085c5abaf708d3d7150", null ],
    [ "magma_clatrd_mgpu", "group__magma__cheev__aux.html#gaedafe8fbd2d8bf3bf130c917ca94b991", null ]
];