var group__magma__ssyev__driver =
[
    [ "magma_ssyevd", "group__magma__ssyev__driver.html#ga8af9f0938c55eb4cb60db488019fcb9a", null ],
    [ "magma_ssyevd_gpu", "group__magma__ssyev__driver.html#ga9a73dd461760b11898a954f0dd96f0ab", null ],
    [ "magma_ssyevd_m", "group__magma__ssyev__driver.html#gad5f91701f2eeaa0ede2f9961b09b3927", null ],
    [ "magma_ssyevdx", "group__magma__ssyev__driver.html#ga94556e48d82b80fee8f97751019d3a97", null ],
    [ "magma_ssyevdx_gpu", "group__magma__ssyev__driver.html#ga63066a174734e387c9a089cc07022f32", null ],
    [ "magma_ssyevdx_m", "group__magma__ssyev__driver.html#ga799dfa8ad62888d9a608a3a5dfd69237", null ]
];