var group__magma__sgesv__aux =
[
    [ "magma_sgetf2_batched", "group__magma__sgesv__aux.html#ga4c4682f11453d533c699feef88b85b17", null ],
    [ "magma_sgetf2_nopiv", "group__magma__sgesv__aux.html#gac0641eeb25b7aeab357d2ce2bfdede80", null ],
    [ "magma_sgetf2_nopiv_batched", "group__magma__sgesv__aux.html#ga0933214ce7edaa324e634bfb14721155", null ]
];