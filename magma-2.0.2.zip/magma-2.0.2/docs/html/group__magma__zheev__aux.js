var group__magma__zheev__aux =
[
    [ "magma_zlatrd", "group__magma__zheev__aux.html#gaf3d87a0561ecd062213c3e410f62c78e", null ],
    [ "magma_zlatrd2", "group__magma__zheev__aux.html#ga0527cca5cfed50b9deadd818a085212d", null ],
    [ "magma_zlatrd_mgpu", "group__magma__zheev__aux.html#ga48bee2c3cd82991d4754ee88617a7680", null ]
];