var group__magma__zblas2 =
[
    [ "magma_zgemv", "group__magma__zblas2.html#ga7e83d793a494a7b700885d0f51e2b0b2", null ],
    [ "magma_zgemv_q", "group__magma__zblas2.html#gaacbea41ec4d58d627bb682952ce6586a", null ],
    [ "magma_zgerc", "group__magma__zblas2.html#gab0351e55114ecd2411c302a22973bd87", null ],
    [ "magma_zgerc_q", "group__magma__zblas2.html#ga173584efe5254fb2bc46afd4421ef151", null ],
    [ "magma_zgeru", "group__magma__zblas2.html#ga8afad7fed41aa6207a8e95498c099678", null ],
    [ "magma_zgeru_q", "group__magma__zblas2.html#gab911e332465a124b3b9f5c28ea2ab78b", null ],
    [ "magma_zhemv", "group__magma__zblas2.html#gaba64ed916bbc280452e3eca296f35d44", null ],
    [ "magma_zhemv_q", "group__magma__zblas2.html#ga39d6cc5fe6033c28d049ac35e260f5fe", null ],
    [ "magma_zher", "group__magma__zblas2.html#gadad7fb3a0c66dac046e1f9e169e50c5a", null ],
    [ "magma_zher2", "group__magma__zblas2.html#ga8228bdd08473efb89b5148e7abe032d8", null ],
    [ "magma_zher2_q", "group__magma__zblas2.html#ga0ae3690e8ba576f72bf39df3da06d50b", null ],
    [ "magma_zher_q", "group__magma__zblas2.html#ga3484b7dec5506f047f311eec0a9cb70c", null ],
    [ "magma_ztrmv", "group__magma__zblas2.html#gaf787c088ea22892853adf82fd00e8363", null ],
    [ "magma_ztrmv_q", "group__magma__zblas2.html#ga1d099e0416822c633dc5b748a0fcb625", null ],
    [ "magma_ztrsv", "group__magma__zblas2.html#gad76b4829548a3f472233558d295d16a9", null ],
    [ "magma_ztrsv_q", "group__magma__zblas2.html#gadb100d156557be20c0c6fb043d27684e", null ],
    [ "magmablas_zgemv", "group__magma__zblas2.html#gaf9b27631e2d3d169711ef3e5c985bd79", null ],
    [ "magmablas_zgemv_conj", "group__magma__zblas2.html#ga108a2f6671c562a4575213eb368e0dba", null ],
    [ "magmablas_zhemv", "group__magma__zblas2.html#ga0ce3fe8b3e02051ac60bd58d6394971c", null ],
    [ "magmablas_zswapblk", "group__magma__zblas2.html#ga3408e7723b8f1d9167fd150d972a8186", null ],
    [ "magmablas_zsymv", "group__magma__zblas2.html#ga95914cef544e492c9f7e1cc88c509cdb", null ]
];