var group__magma__sposv__comp =
[
    [ "magma_spotrf", "group__magma__sposv__comp.html#gaad969b052ce5f6d6340d631c1de8e0fe", null ],
    [ "magma_spotrf3_mgpu", "group__magma__sposv__comp.html#ga4ff7bf113a21bdf56521ec38c1015290", null ],
    [ "magma_spotrf_gpu", "group__magma__sposv__comp.html#gad22d666b533c835430ccab5f2fc7069e", null ],
    [ "magma_spotrf_lg_batched", "group__magma__sposv__comp.html#gae3fe5b0e3e6d20f1799f7ed5f06510d4", null ],
    [ "magma_spotrf_m", "group__magma__sposv__comp.html#gae584741657f7dc0841462e5a6ae07fe1", null ],
    [ "magma_spotrf_mgpu", "group__magma__sposv__comp.html#gada5cc01741d53993ac40b6447df6a0f0", null ],
    [ "magma_spotrf_mgpu_right", "group__magma__sposv__comp.html#gab38ca2a41c5e965cbd5713dafb9a0cbe", null ],
    [ "magma_spotri", "group__magma__sposv__comp.html#gad7d5f8fa42580578c3c0cb71b9b19af6", null ],
    [ "magma_spotri_gpu", "group__magma__sposv__comp.html#ga6bbd3b587e4c15f633bb3e9d07d86593", null ],
    [ "magma_spotrs_batched", "group__magma__sposv__comp.html#ga66c042ba99279f405249675a5c411715", null ],
    [ "magma_spotrs_gpu", "group__magma__sposv__comp.html#ga9c3e25ba93a63747f3ec91a13bb311b8", null ]
];