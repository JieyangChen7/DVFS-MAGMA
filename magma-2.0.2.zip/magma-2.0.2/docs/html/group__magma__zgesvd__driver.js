var group__magma__zgesvd__driver =
[
    [ "magma_zgesdd", "group__magma__zgesvd__driver.html#ga9670752d04d05fa07b6b44a55a51b643", null ],
    [ "magma_zgesvd", "group__magma__zgesvd__driver.html#ga36b9a308e414ee311ec9dba60789e770", null ]
];