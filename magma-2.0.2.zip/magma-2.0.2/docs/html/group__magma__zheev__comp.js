var group__magma__zheev__comp =
[
    [ "magma_zhegst", "group__magma__zheev__comp.html#gaf4d875ad69e36d51a54a896fce0e3a77", null ],
    [ "magma_zhegst_gpu", "group__magma__zheev__comp.html#ga67227c0f248b4ef2cfe7c793a727dfaf", null ],
    [ "magma_zhegst_m", "group__magma__zheev__comp.html#gac5b918d43ccdb7d8f55612f66e82085e", null ],
    [ "magma_zhetrd", "group__magma__zheev__comp.html#ga83a4184e4c72a7a1a319f48acb5b8b70", null ],
    [ "magma_zhetrd2_gpu", "group__magma__zheev__comp.html#gacd02c76b03a9e22fa2d77be85cdbff3e", null ],
    [ "magma_zhetrd_gpu", "group__magma__zheev__comp.html#gadd2bddfe35769e8ebe6f6506c9083df2", null ],
    [ "magma_zhetrd_mgpu", "group__magma__zheev__comp.html#ga1765fa39c6d67a61d4ddf759b988902c", null ],
    [ "magma_zstedx", "group__magma__zheev__comp.html#ga602e5ff0c13993676dc9a80871cd8f65", null ],
    [ "magma_zstedx_m", "group__magma__zheev__comp.html#ga0be2d55ead100c9ca2bb299f4e7bb190", null ],
    [ "magma_zungtr", "group__magma__zheev__comp.html#ga6c072fda35e2938bcbfedebd44d18b5b", null ],
    [ "magma_zunmtr", "group__magma__zheev__comp.html#gae93e463065313593847aa4cfcbc41b6d", null ],
    [ "magma_zunmtr_gpu", "group__magma__zheev__comp.html#gae648d2d43873bb5ec582157417a58041", null ],
    [ "magma_zunmtr_m", "group__magma__zheev__comp.html#gafafda241dfa9217b64dd69fa1a81c9d0", null ]
];