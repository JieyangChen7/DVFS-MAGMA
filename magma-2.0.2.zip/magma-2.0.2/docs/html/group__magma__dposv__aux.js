var group__magma__dposv__aux =
[
    [ "magma_dlauum", "group__magma__dposv__aux.html#ga2e85698d28da1cd03e4b1d12645ad526", null ],
    [ "magma_dlauum_gpu", "group__magma__dposv__aux.html#ga32336c134f67fec4b2720f87f15af23c", null ]
];