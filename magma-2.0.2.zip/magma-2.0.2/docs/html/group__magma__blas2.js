var group__magma__blas2 =
[
    [ "single precision", "group__magma__sblas2.html", "group__magma__sblas2" ],
    [ "double precision", "group__magma__dblas2.html", "group__magma__dblas2" ],
    [ "single-complex precision", "group__magma__cblas2.html", "group__magma__cblas2" ],
    [ "double-complex precision", "group__magma__zblas2.html", "group__magma__zblas2" ]
];