var group__magma__sgeev__comp =
[
    [ "magma_sgehrd", "group__magma__sgeev__comp.html#gacb07accc428ef6465cbd324ca22de9f4", null ],
    [ "magma_sgehrd2", "group__magma__sgeev__comp.html#gaa5bd8bf6f7a9919f08d0d514b1092def", null ],
    [ "magma_sgehrd_m", "group__magma__sgeev__comp.html#ga72ae565c5de1076cc7644b3a49666cf6", null ],
    [ "magma_sorghr", "group__magma__sgeev__comp.html#gae685691899fd83231e10c4570bedcbcc", null ],
    [ "magma_sorghr_m", "group__magma__sgeev__comp.html#ga2fc583c1f23240649c66d0632a7e230a", null ],
    [ "magma_strevc3", "group__magma__sgeev__comp.html#ga35122e49f4ef5652ba8fbf526656a041", null ],
    [ "magma_strevc3_mt", "group__magma__sgeev__comp.html#gaff1854d8ce4fe11d8a2b4ea504648df7", null ]
];