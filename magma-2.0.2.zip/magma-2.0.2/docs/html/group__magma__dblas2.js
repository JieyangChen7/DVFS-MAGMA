var group__magma__dblas2 =
[
    [ "magma_dgemv", "group__magma__dblas2.html#gafee292d21be03554cd7e1c01e7f284f8", null ],
    [ "magma_dgemv_q", "group__magma__dblas2.html#gac62bd9afef61e6980cad0250fff94d7a", null ],
    [ "magma_dger", "group__magma__dblas2.html#ga42b59ec41307a232818bee99062c7856", null ],
    [ "magma_dger_q", "group__magma__dblas2.html#ga21303fa7a792f2fb6e79dc3d23dde8f2", null ],
    [ "magma_dsymv", "group__magma__dblas2.html#ga8cb5b0e6f4feca1a55030fe1dff4f9c0", null ],
    [ "magma_dsymv_q", "group__magma__dblas2.html#ga7e41e016d821f2cb8f9f94cb52aa2822", null ],
    [ "magma_dsyr", "group__magma__dblas2.html#ga7a9bc144c95740fa6b9706b826d4238f", null ],
    [ "magma_dsyr2", "group__magma__dblas2.html#ga31d144ad11a7b6068818e877fe6aa4fc", null ],
    [ "magma_dsyr2_q", "group__magma__dblas2.html#ga85d81fe989c1c96c8b47b66e7f3a2482", null ],
    [ "magma_dsyr_q", "group__magma__dblas2.html#gaa23eb51a8efbcf8f216ad4f6596c0f07", null ],
    [ "magma_dtrmv", "group__magma__dblas2.html#gae415b822531f447b05181452df0adc8d", null ],
    [ "magma_dtrmv_q", "group__magma__dblas2.html#ga5d14f369555295de8446adb8eb146bfe", null ],
    [ "magma_dtrsv", "group__magma__dblas2.html#gaa4b400d79ff1346cc86eeab675a46315", null ],
    [ "magma_dtrsv_q", "group__magma__dblas2.html#gaa6dd55cbcd3acb7cc0966693965a3aa2", null ],
    [ "magmablas_dgemv", "group__magma__dblas2.html#ga7865b0499beddcff3ac13042e6812825", null ],
    [ "magmablas_dgemv_conj", "group__magma__dblas2.html#ga8c2cdedb2e3db4de45795b98baa9aa9b", null ],
    [ "magmablas_dswapblk", "group__magma__dblas2.html#gae5e48635301de373d21fcff3d340e6ef", null ],
    [ "magmablas_dsymv", "group__magma__dblas2.html#ga639e762e9430ed3259c5ba4725a9e0e3", null ]
];