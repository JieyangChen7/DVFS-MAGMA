var group__magma__ssysv__aux =
[
    [ "magma_slasyf_gpu", "group__magma__ssysv__aux.html#ga1a74c52a32aabd151d50cc84748333d0", null ]
];