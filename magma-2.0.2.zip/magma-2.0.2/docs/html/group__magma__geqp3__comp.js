var group__magma__geqp3__comp =
[
    [ "single precision", "group__magma__sgeqp3__comp.html", "group__magma__sgeqp3__comp" ],
    [ "double precision", "group__magma__dgeqp3__comp.html", "group__magma__dgeqp3__comp" ],
    [ "single-complex precision", "group__magma__cgeqp3__comp.html", "group__magma__cgeqp3__comp" ],
    [ "double-complex precision", "group__magma__zgeqp3__comp.html", "group__magma__zgeqp3__comp" ]
];