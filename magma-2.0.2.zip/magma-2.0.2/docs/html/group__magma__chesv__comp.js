var group__magma__chesv__comp =
[
    [ "magma_chetrf", "group__magma__chesv__comp.html#ga6d96339685a66c344b23b236f8078a8d", null ],
    [ "magma_chetrf_aasen", "group__magma__chesv__comp.html#ga5601154e2c0051bcd378c0d0a270220f", null ],
    [ "magma_chetrf_nopiv", "group__magma__chesv__comp.html#gaf1b6af13a8157a259adc74d5f1235164", null ],
    [ "magma_chetrf_nopiv_gpu", "group__magma__chesv__comp.html#ga8a201a5dcb4216e9c9f994ecd334f49d", null ],
    [ "magma_chetrs_nopiv_gpu", "group__magma__chesv__comp.html#ga1b629f1775ab53b9db32efcda0c55e6e", null ]
];