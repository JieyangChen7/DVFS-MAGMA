var group__magma__zsysv__driver =
[
    [ "magma_zsysv_nopiv_gpu", "group__magma__zsysv__driver.html#ga1fc02db0b8af3df93f1702cd6c7e131a", null ]
];