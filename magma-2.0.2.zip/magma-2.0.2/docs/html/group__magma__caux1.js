var group__magma__caux1 =
[
    [ "magma_clarfg_gpu", "group__magma__caux1.html#gaf9dbafc793c1d58c95c0d3d75a97fb16", null ],
    [ "magma_clarfgtx_gpu", "group__magma__caux1.html#ga757c273111b8264b383d2e586249d814", null ],
    [ "magma_clarfgx_gpu", "group__magma__caux1.html#gaf128179ec43b09847ea62a982b48e30f", null ],
    [ "magma_clarfx_gpu", "group__magma__caux1.html#gaa3fc0c64d1f69f613473be8ad1af22ab", null ],
    [ "magmablas_clarfg", "group__magma__caux1.html#gad907058eeef0d3b4179a1c378bdaf23e", null ]
];