var group__magma__zgeev__comp =
[
    [ "magma_zgehrd", "group__magma__zgeev__comp.html#ga59b3208e254f07a7ca558a04688491d3", null ],
    [ "magma_zgehrd2", "group__magma__zgeev__comp.html#gaac48785795551dd094537cb973463760", null ],
    [ "magma_zgehrd_m", "group__magma__zgeev__comp.html#gae2f50969964a565c4a37f0f7350f4f32", null ],
    [ "magma_ztrevc3", "group__magma__zgeev__comp.html#ga9f6ca591a54f2908a00788edf8ba04cd", null ],
    [ "magma_ztrevc3_mt", "group__magma__zgeev__comp.html#ga1f0e1380c51ab50558db79e723795f18", null ],
    [ "magma_zunghr", "group__magma__zgeev__comp.html#gab299c0844d352d94c5f1070cf358db63", null ],
    [ "magma_zunghr_m", "group__magma__zgeev__comp.html#ga228476d1a2bc93028785b610a6f52848", null ],
    [ "ztrevc3", "group__magma__zgeev__comp.html#ga66e85621c715ab3b2eb21b1a264983a3", null ]
];