var group__magma__sgeqp3__aux =
[
    [ "magma_slaqps", "group__magma__sgeqp3__aux.html#ga9e7994efd66eb01de20cc0532d271465", null ],
    [ "magma_slaqps_gpu", "group__magma__sgeqp3__aux.html#ga32a8d7313676c34364b58c91a352b7e2", null ]
];