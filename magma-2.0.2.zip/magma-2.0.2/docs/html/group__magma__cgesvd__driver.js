var group__magma__cgesvd__driver =
[
    [ "magma_cgesdd", "group__magma__cgesvd__driver.html#gabdfa5370c04558dc13a6431907fe0c05", null ],
    [ "magma_cgesvd", "group__magma__cgesvd__driver.html#ga4fabaf4f2eb541d45768429d7ef8979a", null ]
];