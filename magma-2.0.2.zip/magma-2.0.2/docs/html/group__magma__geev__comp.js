var group__magma__geev__comp =
[
    [ "single precision", "group__magma__sgeev__comp.html", "group__magma__sgeev__comp" ],
    [ "double precision", "group__magma__dgeev__comp.html", "group__magma__dgeev__comp" ],
    [ "single-complex precision", "group__magma__cgeev__comp.html", "group__magma__cgeev__comp" ],
    [ "double-complex precision", "group__magma__zgeev__comp.html", "group__magma__zgeev__comp" ]
];