var group__magma__ssygv__driver =
[
    [ "magma_ssygvd", "group__magma__ssygv__driver.html#ga30790c840604af8b7754391dfda8e14a", null ],
    [ "magma_ssygvd_m", "group__magma__ssygv__driver.html#gad0f4d4d3825acbf80c9b97bda0be05d7", null ],
    [ "magma_ssygvdx", "group__magma__ssygv__driver.html#ga171ae3b48646e98d70fdb8e9a8cbde4c", null ],
    [ "magma_ssygvdx_m", "group__magma__ssygv__driver.html#ga1694ef4a0b3cc533d27a1c36d93ca7c3", null ]
];