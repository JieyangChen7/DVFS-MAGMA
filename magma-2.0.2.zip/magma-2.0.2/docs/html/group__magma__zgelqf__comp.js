var group__magma__zgelqf__comp =
[
    [ "magma_zgelqf", "group__magma__zgelqf__comp.html#gafceedfc30d6813fc9da9dbba58c331db", null ],
    [ "magma_zgelqf_gpu", "group__magma__zgelqf__comp.html#ga042d24c359f519f5e7cf1e8d8c5a57e8", null ],
    [ "magma_zunglq", "group__magma__zgelqf__comp.html#gafc0f2b7abcf687d0e5838d6cde9865ae", null ],
    [ "magma_zunmlq", "group__magma__zgelqf__comp.html#ga48193aac4643d88878b52374445dca28", null ]
];