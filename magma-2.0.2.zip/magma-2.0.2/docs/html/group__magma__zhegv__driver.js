var group__magma__zhegv__driver =
[
    [ "magma_zhegvd", "group__magma__zhegv__driver.html#gae817827f8a18eeb259216effbf7ad241", null ],
    [ "magma_zhegvd_m", "group__magma__zhegv__driver.html#ga6edeb26d29b05b101ceca6aeeef81c91", null ],
    [ "magma_zhegvdx", "group__magma__zhegv__driver.html#ga6a3b281f45798cacf3bac4ab8cc1bbe2", null ],
    [ "magma_zhegvdx_2stage", "group__magma__zhegv__driver.html#gafbab9a98f410127d23511fad2e729bd9", null ],
    [ "magma_zhegvdx_2stage_m", "group__magma__zhegv__driver.html#ga9ff715cf5a2d7bd78c9e9cea28c14a32", null ],
    [ "magma_zhegvdx_m", "group__magma__zhegv__driver.html#ga28f61d591f7dc3d00d3cdd36116af96d", null ],
    [ "magma_zhegvr", "group__magma__zhegv__driver.html#ga01d82620599e377a181806892d3d6951", null ],
    [ "magma_zhegvx", "group__magma__zhegv__driver.html#gabcf417948c6ebc60a219f68041e6eb40", null ]
];