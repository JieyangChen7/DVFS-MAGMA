var group__magma__sgels__comp =
[
    [ "magma_sgeqrs3_gpu", "group__magma__sgels__comp.html#gacee6ee738006f47dc2bd201e778c1939", null ],
    [ "magma_sgeqrs_gpu", "group__magma__sgels__comp.html#ga879e8eda4f8360109974647d1325f9ea", null ]
];