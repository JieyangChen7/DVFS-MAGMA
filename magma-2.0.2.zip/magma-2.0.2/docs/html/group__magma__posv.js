var group__magma__posv =
[
    [ "Cholesky solve: driver", "group__magma__posv__driver.html", "group__magma__posv__driver" ],
    [ "Cholesky solve: computational", "group__magma__posv__comp.html", "group__magma__posv__comp" ],
    [ "Cholesky solve: auxiliary", "group__magma__posv__aux.html", "group__magma__posv__aux" ]
];