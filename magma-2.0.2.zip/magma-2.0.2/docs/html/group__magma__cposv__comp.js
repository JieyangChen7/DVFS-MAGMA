var group__magma__cposv__comp =
[
    [ "magma_cpotrf", "group__magma__cposv__comp.html#ga33f754da54ca96954192080b7b02e66e", null ],
    [ "magma_cpotrf3_mgpu", "group__magma__cposv__comp.html#ga0cde88def467d61f107ad44e1f00b722", null ],
    [ "magma_cpotrf_gpu", "group__magma__cposv__comp.html#ga18a6903c31791afda5d02338589cc6cf", null ],
    [ "magma_cpotrf_lg_batched", "group__magma__cposv__comp.html#ga0915f5aa61bbb89e82cb405126587133", null ],
    [ "magma_cpotrf_m", "group__magma__cposv__comp.html#ga4f3d3f4005846d2d56607a1c4eefe494", null ],
    [ "magma_cpotrf_mgpu", "group__magma__cposv__comp.html#ga014bd0d84d0fd907aef6d9e784570c73", null ],
    [ "magma_cpotrf_mgpu_right", "group__magma__cposv__comp.html#ga6380040cb7945857c59bb4f223bc15c2", null ],
    [ "magma_cpotri", "group__magma__cposv__comp.html#gaead020e5e33e47ef4e6ce5ab534b22d8", null ],
    [ "magma_cpotri_gpu", "group__magma__cposv__comp.html#ga24dbe6246a1f5577d99d31341bef9410", null ],
    [ "magma_cpotrs_batched", "group__magma__cposv__comp.html#gaef3f793acad337b53fb48b6ad97afb2f", null ],
    [ "magma_cpotrs_gpu", "group__magma__cposv__comp.html#gafb13130df98fc1245d4dd1837ab2c6e7", null ]
];