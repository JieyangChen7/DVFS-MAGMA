var group__magma__cgeqp3__aux =
[
    [ "magma_claqps", "group__magma__cgeqp3__aux.html#gaaade72756462f7b9a2dce3318be411d2", null ],
    [ "magma_claqps_gpu", "group__magma__cgeqp3__aux.html#ga828099ff0760147d8f4555c63f0435fc", null ]
];