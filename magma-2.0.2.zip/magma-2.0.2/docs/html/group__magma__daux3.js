var group__magma__daux3 =
[
    [ "magma_dlarfb_gemm_batched", "group__magma__daux3.html#gaa8f72568401fac86b111f99cd73e0f23", null ],
    [ "magma_dlarfb_gpu", "group__magma__daux3.html#ga6a49fe1bdeaf4d87b4b861f5ea570952", null ],
    [ "magma_dlarfb_gpu_gemm", "group__magma__daux3.html#ga5730203c341568f54cff58f1325c2486", null ],
    [ "magma_dlarfb_gpu_gemm_q", "group__magma__daux3.html#gaea8cceeefeea11fef84db50caa9c920b", null ],
    [ "magma_dlarfb_gpu_q", "group__magma__daux3.html#ga2c589f5116b8d526305ab2f676277fa2", null ],
    [ "magma_dlarfbx_gpu", "group__magma__daux3.html#ga94d9027179add67dd93e4a54b03fbfa9", null ],
    [ "magma_dlarfy", "group__magma__daux3.html#gab8c0f2e3a3f54811107d7b6e947f04b0", null ]
];