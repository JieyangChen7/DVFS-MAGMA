var group__magma__aux2 =
[
    [ "single precision", "group__magma__saux2.html", "group__magma__saux2" ],
    [ "double precision", "group__magma__daux2.html", "group__magma__daux2" ],
    [ "single-complex precision", "group__magma__caux2.html", "group__magma__caux2" ],
    [ "double-complex precision", "group__magma__zaux2.html", "group__magma__zaux2" ]
];