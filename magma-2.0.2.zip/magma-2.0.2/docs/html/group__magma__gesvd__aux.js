var group__magma__gesvd__aux =
[
    [ "single precision", "group__magma__sgesvd__aux.html", "group__magma__sgesvd__aux" ],
    [ "double precision", "group__magma__dgesvd__aux.html", "group__magma__dgesvd__aux" ],
    [ "single-complex precision", "group__magma__cgesvd__aux.html", "group__magma__cgesvd__aux" ],
    [ "double-complex precision", "group__magma__zgesvd__aux.html", "group__magma__zgesvd__aux" ]
];