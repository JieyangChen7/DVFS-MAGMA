var group__magma__dgels__driver =
[
    [ "magma_dgels", "group__magma__dgels__driver.html#ga4638ad21c7392a0bd22440a4827c0b0d", null ],
    [ "magma_dgels3_gpu", "group__magma__dgels__driver.html#gaf4d664f17065304d74cd1f06623d1ff3", null ],
    [ "magma_dgels_gpu", "group__magma__dgels__driver.html#ga4cee0665fc8c54b018e8f44251f16e53", null ],
    [ "magma_dsgeqrsv_gpu", "group__magma__dgels__driver.html#gaf46e8271b97f94505cb77f0c499b6256", null ]
];