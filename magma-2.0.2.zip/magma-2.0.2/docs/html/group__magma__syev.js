var group__magma__syev =
[
    [ "Symmetric eigenvalue: driver", "group__magma__syev__driver.html", "group__magma__syev__driver" ],
    [ "Generalized symmetric eigenvalue: driver", "group__magma__sygv__driver.html", "group__magma__sygv__driver" ],
    [ "Symmetric eigenvalue: computational", "group__magma__syev__comp.html", "group__magma__syev__comp" ],
    [ "Symmetric eigenvalue: computational, 2-stage", "group__magma__syev__2stage.html", "group__magma__syev__2stage" ],
    [ "Symmetric eigenvalue: auxiliary", "group__magma__syev__aux.html", "group__magma__syev__aux" ]
];