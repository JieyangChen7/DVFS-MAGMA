var group__magma__caux3 =
[
    [ "magma_clarfb_gemm_batched", "group__magma__caux3.html#ga4b730f6fb7f010cb5a922c20ca8642d9", null ],
    [ "magma_clarfb_gpu", "group__magma__caux3.html#gaaa441f1c4cc56b4aa0e9a051464d86a1", null ],
    [ "magma_clarfb_gpu_gemm", "group__magma__caux3.html#ga4a972c3c6f2f69e9153d44721fc000c6", null ],
    [ "magma_clarfb_gpu_gemm_q", "group__magma__caux3.html#ga506c46254b10dbb68f8af57777f1f170", null ],
    [ "magma_clarfb_gpu_q", "group__magma__caux3.html#gab7ff486ba86719b1e3056260672ab408", null ],
    [ "magma_clarfbx_gpu", "group__magma__caux3.html#ga8fc6a1a6f1b34b5b2c0ae6b5e7d066f0", null ],
    [ "magma_clarfy", "group__magma__caux3.html#ga0d615cceffdc5f15f010af09194849a3", null ]
];