var group__magma__blas1 =
[
    [ "single precision", "group__magma__sblas1.html", "group__magma__sblas1" ],
    [ "double precision", "group__magma__dblas1.html", "group__magma__dblas1" ],
    [ "single-complex precision", "group__magma__cblas1.html", "group__magma__cblas1" ],
    [ "double-complex precision", "group__magma__zblas1.html", "group__magma__zblas1" ]
];