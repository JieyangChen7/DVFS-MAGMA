var group__magma__dgesvd__comp =
[
    [ "magma_dgebrd", "group__magma__dgesvd__comp.html#ga41e57b1939ac0a650d1d3b2e7a51ad25", null ],
    [ "magma_dorgbr", "group__magma__dgesvd__comp.html#gadb057b650e298e12007fb33fefb59b6e", null ],
    [ "magma_dormbr", "group__magma__dgesvd__comp.html#ga42049b8b3f24f2cb53e2e4683f2e12a6", null ]
];