var group__magma__zgeqlf__comp =
[
    [ "magma_zgeqlf", "group__magma__zgeqlf__comp.html#ga6b770bbe1ed276fd2c6fde8e933867eb", null ],
    [ "magma_zunmql", "group__magma__zgeqlf__comp.html#ga974a7229cc529b9c524e412392f6da96", null ],
    [ "magma_zunmql2_gpu", "group__magma__zgeqlf__comp.html#ga1e95fc40f3576257426a3d7252d5e93c", null ]
];