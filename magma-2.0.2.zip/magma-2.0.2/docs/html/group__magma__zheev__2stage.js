var group__magma__zheev__2stage =
[
    [ "magma_zhetrd_hb2st", "group__magma__zheev__2stage.html#gab58960239a6fa7651fb30f365fd4f8e8", null ],
    [ "magma_zhetrd_he2hb", "group__magma__zheev__2stage.html#ga9fdf521011a15fed84f468d02edd5143", null ],
    [ "magma_zhetrd_he2hb_mgpu", "group__magma__zheev__2stage.html#ga9b86d96a112efa7ca7d074d80d14a0c0", null ],
    [ "magma_zungqr_2stage_gpu", "group__magma__zheev__2stage.html#gaeebbd59a1e59ecdc9e2a32eff17275a5", null ],
    [ "magma_zunmqr_gpu_2stages", "group__magma__zheev__2stage.html#ga3d0e5d5e3133901a98f012bcc997d277", null ]
];