var group__magma__zhesv__comp =
[
    [ "magma_zhetrf", "group__magma__zhesv__comp.html#gaad027d1a463d4cd44e228f167a1dca67", null ],
    [ "magma_zhetrf_aasen", "group__magma__zhesv__comp.html#ga928950105a476d9a6696882d8096dec1", null ],
    [ "magma_zhetrf_nopiv", "group__magma__zhesv__comp.html#ga488b320ec54ab4814ce5671b094cdbb1", null ],
    [ "magma_zhetrf_nopiv_gpu", "group__magma__zhesv__comp.html#ga8009a926922392cf58441667a06b236e", null ],
    [ "magma_zhetrs_nopiv_gpu", "group__magma__zhesv__comp.html#gaba5a88a1dbcba9ab1ca7665c3b43b19f", null ]
];