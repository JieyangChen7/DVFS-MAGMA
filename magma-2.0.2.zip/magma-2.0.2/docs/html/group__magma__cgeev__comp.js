var group__magma__cgeev__comp =
[
    [ "magma_cgehrd", "group__magma__cgeev__comp.html#gabb038016a7f499c46c604650880be711", null ],
    [ "magma_cgehrd2", "group__magma__cgeev__comp.html#ga1ef7dda30b2691ad6f37ec76082dc641", null ],
    [ "magma_cgehrd_m", "group__magma__cgeev__comp.html#ga99a6ce9ed9c039351a24148bd635efd5", null ],
    [ "magma_ctrevc3", "group__magma__cgeev__comp.html#gaabe4c9003c1b68ccea6e5a64875a3e6f", null ],
    [ "magma_ctrevc3_mt", "group__magma__cgeev__comp.html#gab683d09689da0d357666194408411673", null ],
    [ "magma_cunghr", "group__magma__cgeev__comp.html#ga09a558890c516640ef81f1205b691310", null ],
    [ "magma_cunghr_m", "group__magma__cgeev__comp.html#ga837c62a892423c53dc421c473c4aca92", null ]
];