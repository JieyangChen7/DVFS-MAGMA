var group__magma__dposv__comp =
[
    [ "magma_dpotrf", "group__magma__dposv__comp.html#gaf0f1a16f06b6b09293dfc36a55486ef8", null ],
    [ "magma_dpotrf3_mgpu", "group__magma__dposv__comp.html#ga538a49e4d252435426c07920af959182", null ],
    [ "magma_dpotrf_gpu", "group__magma__dposv__comp.html#ga95db876a9eb3392b00dbd846f229bc79", null ],
    [ "magma_dpotrf_lg_batched", "group__magma__dposv__comp.html#gafdfd640d46b0b88eabb052f6ea637977", null ],
    [ "magma_dpotrf_m", "group__magma__dposv__comp.html#ga31587a1e9768a115d5fadccfb31e0f84", null ],
    [ "magma_dpotrf_mgpu", "group__magma__dposv__comp.html#ga80003fa2d525a8bdcc684e82d5d80e70", null ],
    [ "magma_dpotrf_mgpu_right", "group__magma__dposv__comp.html#gaa32b0ee8745366be2eb7d726821a00bb", null ],
    [ "magma_dpotri", "group__magma__dposv__comp.html#gaaea46c7d21fdc62e0e344fd683a04b7f", null ],
    [ "magma_dpotri_gpu", "group__magma__dposv__comp.html#ga3c7c8d8bcba5dea50528e7f8c8095a59", null ],
    [ "magma_dpotrs_batched", "group__magma__dposv__comp.html#gac4e899af13d1a3bb46ffba5729e77170", null ],
    [ "magma_dpotrs_gpu", "group__magma__dposv__comp.html#ga15514cf1020a8fea8f4fe7c242b09882", null ]
];