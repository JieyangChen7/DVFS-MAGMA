var group__magma__sgesvd__driver =
[
    [ "magma_sgesdd", "group__magma__sgesvd__driver.html#ga1af7fbb2b1ea64aa347fc95e3924aca5", null ],
    [ "magma_sgesvd", "group__magma__sgesvd__driver.html#ga96e26a734d9c48e5c994863c4e2d83f1", null ]
];