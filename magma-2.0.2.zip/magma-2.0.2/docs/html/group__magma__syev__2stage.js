var group__magma__syev__2stage =
[
    [ "single precision", "group__magma__ssyev__2stage.html", "group__magma__ssyev__2stage" ],
    [ "double precision", "group__magma__dsyev__2stage.html", "group__magma__dsyev__2stage" ],
    [ "single-complex precision", "group__magma__cheev__2stage.html", "group__magma__cheev__2stage" ],
    [ "double-complex precision", "group__magma__zheev__2stage.html", "group__magma__zheev__2stage" ]
];