var group__magma__gesv =
[
    [ "LU solve: driver", "group__magma__gesv__driver.html", "group__magma__gesv__driver" ],
    [ "LU solve: computational", "group__magma__gesv__comp.html", "group__magma__gesv__comp" ],
    [ "LU solve: auxiliary", "group__magma__gesv__aux.html", "group__magma__gesv__aux" ],
    [ "Tiled LU", "group__magma__gesv__tile.html", "group__magma__gesv__tile" ]
];