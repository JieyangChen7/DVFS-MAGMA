var group__magma__zaux3 =
[
    [ "magma_zlarfb_gemm_batched", "group__magma__zaux3.html#gab074b1c6e535442ada7dbffb2511226a", null ],
    [ "magma_zlarfb_gpu", "group__magma__zaux3.html#ga6dcbd96bcac68adff0deffe21ef00338", null ],
    [ "magma_zlarfb_gpu_gemm", "group__magma__zaux3.html#gaea5c7378ed2d271ffe4aa04b084878c3", null ],
    [ "magma_zlarfb_gpu_gemm_q", "group__magma__zaux3.html#gaaf690dfdf41f65e43a15b711bab4ba2c", null ],
    [ "magma_zlarfb_gpu_q", "group__magma__zaux3.html#ga757caff320f21d9edd7df7d96c7fdb49", null ],
    [ "magma_zlarfbx_gpu", "group__magma__zaux3.html#ga0f53e33b53ab63064b9c0696b7dee7f3", null ],
    [ "magma_zlarfy", "group__magma__zaux3.html#gaf3dcd543dee22e890544748dc2cf47b9", null ]
];