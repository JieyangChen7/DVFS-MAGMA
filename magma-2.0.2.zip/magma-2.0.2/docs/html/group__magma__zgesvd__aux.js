var group__magma__zgesvd__aux =
[
    [ "magma_zlabrd_gpu", "group__magma__zgesvd__aux.html#gacd1b6402d6f1fb145131a47b6639a36b", null ]
];