var group__magma__ssyev__aux =
[
    [ "magma_slaex0", "group__magma__ssyev__aux.html#gac313c402f8f19855ac34f5817a0cc36c", null ],
    [ "magma_slaex0_m", "group__magma__ssyev__aux.html#ga3c0f404477bef13845c79ec722e47193", null ],
    [ "magma_slaex1", "group__magma__ssyev__aux.html#ga79c27b9ca789c2852211853ac2839a78", null ],
    [ "magma_slaex1_m", "group__magma__ssyev__aux.html#gab9cfad7d200374a2fbc4fdd90e34977c", null ],
    [ "magma_slaex3", "group__magma__ssyev__aux.html#gaaa3dbe7204942182b20b6c7cda2761aa", null ],
    [ "magma_slaex3_m", "group__magma__ssyev__aux.html#ga613dbf483e218a420a8a920315c7b907", null ],
    [ "magma_slatrd", "group__magma__ssyev__aux.html#ga2d8f2e548c336e4dcc812822e2419982", null ],
    [ "magma_slatrd2", "group__magma__ssyev__aux.html#ga1126e57c4d67e8209315baaf6289ac8a", null ],
    [ "magma_slatrd_mgpu", "group__magma__ssyev__aux.html#gab80c97277be61852cbed423650d68aab", null ]
];