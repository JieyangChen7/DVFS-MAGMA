var group__magma__dgeqp3__aux =
[
    [ "magma_dlaqps", "group__magma__dgeqp3__aux.html#ga5abaaf08c8f4a18e11586866ba0bbaa7", null ],
    [ "magma_dlaqps_gpu", "group__magma__dgeqp3__aux.html#gaf8a265eb38ec15831224a1c3c7cc0cc7", null ]
];