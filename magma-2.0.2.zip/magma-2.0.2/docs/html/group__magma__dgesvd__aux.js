var group__magma__dgesvd__aux =
[
    [ "magma_dlabrd_gpu", "group__magma__dgesvd__aux.html#ga2b524aff558b6c35f4b4a6c22da78397", null ]
];