var group__magma__sgels__driver =
[
    [ "magma_sgels", "group__magma__sgels__driver.html#gaaf1d00b107f2c5c058465263a0e66870", null ],
    [ "magma_sgels3_gpu", "group__magma__sgels__driver.html#ga6102400f064b371575a8f575eb5cf0de", null ],
    [ "magma_sgels_gpu", "group__magma__sgels__driver.html#ga92025de26e24648d31dfba2cfb07a848", null ]
];