var group__magma__sposv__driver =
[
    [ "magma_sposv", "group__magma__sposv__driver.html#gafdc0f7db573a1cc1c4d1efb603861e42", null ],
    [ "magma_sposv_batched", "group__magma__sposv__driver.html#ga6c6e5950910d481a20c58fb7aa5ddaa3", null ],
    [ "magma_sposv_gpu", "group__magma__sposv__driver.html#gad6ad2a6b7ca4e0d80f9a080bb8b1f0a4", null ]
];