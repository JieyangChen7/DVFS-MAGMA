var group__magma__geqp3__aux =
[
    [ "single precision", "group__magma__sgeqp3__aux.html", "group__magma__sgeqp3__aux" ],
    [ "double precision", "group__magma__dgeqp3__aux.html", "group__magma__dgeqp3__aux" ],
    [ "single-complex precision", "group__magma__cgeqp3__aux.html", "group__magma__cgeqp3__aux" ],
    [ "double-complex precision", "group__magma__zgeqp3__aux.html", "group__magma__zgeqp3__aux" ]
];