var group__magma__geqrf =
[
    [ "QR factorization: computational", "group__magma__geqrf__comp.html", "group__magma__geqrf__comp" ],
    [ "QR factorization: auxiliary", "group__magma__geqrf__aux.html", "group__magma__geqrf__aux" ],
    [ "QR with pivoting", "group__magma__geqp3__comp.html", "group__magma__geqp3__comp" ],
    [ "QR with pivoting: auxiliary", "group__magma__geqp3__aux.html", "group__magma__geqp3__aux" ],
    [ "Tiled QR factorization", "group__magma__geqrf__tile.html", "group__magma__geqrf__tile" ]
];