var group__magma__daux1 =
[
    [ "magma_dlarfg_gpu", "group__magma__daux1.html#ga5938bc8020578755179c9abccd39950d", null ],
    [ "magma_dlarfgtx_gpu", "group__magma__daux1.html#gac3473cb66dbcf84d3c3c2f61c3ec3248", null ],
    [ "magma_dlarfgx_gpu", "group__magma__daux1.html#gaa6b5cca2a9c54d99de4e6fd14cc01575", null ],
    [ "magma_dlarfx_gpu", "group__magma__daux1.html#ga32fdd125733441136e16ea151ec62be0", null ],
    [ "magmablas_dlarfg", "group__magma__daux1.html#gaf57a95772f64b629cfdea5a8249d8374", null ]
];