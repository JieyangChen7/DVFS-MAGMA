var group__magma__zhesv__aux =
[
    [ "magma_zlahef_gpu", "group__magma__zhesv__aux.html#ga4571a53fe4ad67a4008a3df93ff0027f", null ]
];