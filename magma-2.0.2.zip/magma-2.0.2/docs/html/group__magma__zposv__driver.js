var group__magma__zposv__driver =
[
    [ "magma_zcposv_gpu", "group__magma__zposv__driver.html#ga839665a6a7c2ef08f57be63232fc1742", null ],
    [ "magma_zposv", "group__magma__zposv__driver.html#gab3d8b156c44452041efd03a4c4061615", null ],
    [ "magma_zposv_batched", "group__magma__zposv__driver.html#gaabbb2721a8b8df5e91319ae35ddeb52c", null ],
    [ "magma_zposv_gpu", "group__magma__zposv__driver.html#gac17514a43cabfd62526a10ad4adb12ef", null ]
];