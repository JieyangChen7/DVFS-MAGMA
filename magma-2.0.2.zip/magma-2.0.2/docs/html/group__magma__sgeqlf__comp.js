var group__magma__sgeqlf__comp =
[
    [ "magma_sgeqlf", "group__magma__sgeqlf__comp.html#ga46c5120736ffe860399019b2ecdd0c39", null ],
    [ "magma_sormql", "group__magma__sgeqlf__comp.html#ga1f5dfed0430ccbafeaac13c2e8e8c428", null ],
    [ "magma_sormql2_gpu", "group__magma__sgeqlf__comp.html#gaf8aa7b092b88292fdf9e93e1a49c1c49", null ]
];