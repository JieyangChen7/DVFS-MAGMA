var group__magma__dgeqp3__comp =
[
    [ "magma_dgeqp3", "group__magma__dgeqp3__comp.html#ga8e432999a48895380f8aefa018b5d1fc", null ],
    [ "magma_dgeqp3_gpu", "group__magma__dgeqp3__comp.html#ga3d41a52e8f88652207144a05203d9ea6", null ]
];