var group__magma__cgeqlf__comp =
[
    [ "magma_cgeqlf", "group__magma__cgeqlf__comp.html#ga8ad96de5d1dcb18078832935150dbad3", null ],
    [ "magma_cunmql", "group__magma__cgeqlf__comp.html#ga969fc79f474bd4612842cb6ee5b5358a", null ],
    [ "magma_cunmql2_gpu", "group__magma__cgeqlf__comp.html#ga9b984fde6294d28aba0746bd567da9f7", null ]
];