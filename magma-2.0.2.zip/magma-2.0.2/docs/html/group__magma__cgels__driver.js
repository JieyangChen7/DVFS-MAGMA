var group__magma__cgels__driver =
[
    [ "magma_cgels", "group__magma__cgels__driver.html#ga1e6241db5333b5d3be0d1835a3133d2d", null ],
    [ "magma_cgels3_gpu", "group__magma__cgels__driver.html#ga9908cd5e427774eae5238866107ec3e5", null ],
    [ "magma_cgels_gpu", "group__magma__cgels__driver.html#gaec9ae710930ccbb83779bf41c6315f1b", null ]
];