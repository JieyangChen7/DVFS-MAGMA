var group__magma__dposv__driver =
[
    [ "magma_dposv", "group__magma__dposv__driver.html#ga99e6afe95ac614d252c5746c680a301f", null ],
    [ "magma_dposv_batched", "group__magma__dposv__driver.html#gab04ffe198b0db7c29d92898653e93c19", null ],
    [ "magma_dposv_gpu", "group__magma__dposv__driver.html#gab4bc23107dca3f77974079d952906983", null ],
    [ "magma_dsposv_gpu", "group__magma__dposv__driver.html#ga57f665e5bbbad48fa1c3b1a3fcef9ff3", null ]
];