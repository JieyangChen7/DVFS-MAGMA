var group__magma__gelqf__comp =
[
    [ "single precision", "group__magma__sgelqf__comp.html", "group__magma__sgelqf__comp" ],
    [ "double precision", "group__magma__dgelqf__comp.html", "group__magma__dgelqf__comp" ],
    [ "single-complex precision", "group__magma__cgelqf__comp.html", "group__magma__cgelqf__comp" ],
    [ "double-complex precision", "group__magma__zgelqf__comp.html", "group__magma__zgelqf__comp" ]
];