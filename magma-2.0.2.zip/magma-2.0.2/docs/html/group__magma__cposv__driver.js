var group__magma__cposv__driver =
[
    [ "magma_cposv", "group__magma__cposv__driver.html#ga204dd8f5eef2228eb18fc24f98fe3861", null ],
    [ "magma_cposv_batched", "group__magma__cposv__driver.html#ga3a81ad0938259354183f48571e1b6be3", null ],
    [ "magma_cposv_gpu", "group__magma__cposv__driver.html#ga8c046a4f555e590dcdb70a0145faa73d", null ]
];