var group__magma__gels__comp =
[
    [ "single precision", "group__magma__sgels__comp.html", "group__magma__sgels__comp" ],
    [ "double precision", "group__magma__dgels__comp.html", "group__magma__dgels__comp" ],
    [ "single-complex precision", "group__magma__cgels__comp.html", "group__magma__cgels__comp" ],
    [ "double-complex precision", "group__magma__zgels__comp.html", "group__magma__zgels__comp" ]
];