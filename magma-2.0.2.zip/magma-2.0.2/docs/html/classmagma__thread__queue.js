var classmagma__thread__queue =
[
    [ "magma_thread_queue", "classmagma__thread__queue.html#a8509f1128d7315a848631020ed571779", null ],
    [ "~magma_thread_queue", "classmagma__thread__queue.html#a85f9f3471cd59153184327d0ec015bd1", null ],
    [ "get_thread_index", "classmagma__thread__queue.html#a65afbd1d75b551159d75e69dc0258b0f", null ],
    [ "launch", "classmagma__thread__queue.html#a357744e19d6baf75b014f7f692cbf0ea", null ],
    [ "pop_task", "classmagma__thread__queue.html#a2819b023e5d04949f96d5f142eeec13d", null ],
    [ "push_task", "classmagma__thread__queue.html#a9220f8ad5466f976dcc094f492474e93", null ],
    [ "quit", "classmagma__thread__queue.html#a289689493610414cfa716dce2561e6cf", null ],
    [ "sync", "classmagma__thread__queue.html#a131b04a3dadf057fa5c13a6395096c9e", null ],
    [ "task_done", "classmagma__thread__queue.html#ad9ee2c11aae7957647606d6ea06b0db6", null ],
    [ "magma_thread_main", "classmagma__thread__queue.html#a67218e4b6080631da1d3b04dd2f44ab9", null ]
];