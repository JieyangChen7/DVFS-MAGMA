var group__magma__cgeqrf__comp =
[
    [ "magma_cgegqr_gpu", "group__magma__cgeqrf__comp.html#ga8d2f78c5918ebe07f11d7254cc0c57a3", null ],
    [ "magma_cgeqrf", "group__magma__cgeqrf__comp.html#gafa44da821d7604850f2312508f2169fa", null ],
    [ "magma_cgeqrf2_gpu", "group__magma__cgeqrf__comp.html#ga07dd456a4310e62593c054901b0da066", null ],
    [ "magma_cgeqrf2_mgpu", "group__magma__cgeqrf__comp.html#ga1e426872ec5f9c1f655408185d0f6ba5", null ],
    [ "magma_cgeqrf3_gpu", "group__magma__cgeqrf__comp.html#gad5645c52f199b38ae312e2ba6487b983", null ],
    [ "magma_cgeqrf_batched", "group__magma__cgeqrf__comp.html#gae786a49211836615f06993c334bd1f51", null ],
    [ "magma_cgeqrf_expert_batched", "group__magma__cgeqrf__comp.html#ga9de2be60413a20186896b509fdbcfb4f", null ],
    [ "magma_cgeqrf_gpu", "group__magma__cgeqrf__comp.html#ga2e0fe71d20eefe9ee93228847d903919", null ],
    [ "magma_cgeqrf_m", "group__magma__cgeqrf__comp.html#gab11a0a2df61c18dfe32f88b707b5b49d", null ],
    [ "magma_cgeqrf_ooc", "group__magma__cgeqrf__comp.html#gae0d389127fc30221001c9e48c5997cf6", null ],
    [ "magma_cungqr", "group__magma__cgeqrf__comp.html#ga3eaf1476be8170dc55ef3a8f880f160a", null ],
    [ "magma_cungqr2", "group__magma__cgeqrf__comp.html#ga0763ba33f969ebf9225c731c9c647157", null ],
    [ "magma_cungqr_gpu", "group__magma__cgeqrf__comp.html#ga5550b69ca22e2ebd7977847bd751f802", null ],
    [ "magma_cungqr_m", "group__magma__cgeqrf__comp.html#gad8f54392cefa69d2a7b48f5c74fac03d", null ],
    [ "magma_cunmqr", "group__magma__cgeqrf__comp.html#gab71088b3e710272db4944b8303c1f190", null ],
    [ "magma_cunmqr2_gpu", "group__magma__cgeqrf__comp.html#ga2b3ca82d7fe0416112733bfa25cd21c1", null ],
    [ "magma_cunmqr_gpu", "group__magma__cgeqrf__comp.html#gae144558c91b463b428740f3f9dc91bf6", null ],
    [ "magma_cunmqr_m", "group__magma__cgeqrf__comp.html#ga9ff16342d839dbfe0fe82e22523c57c2", null ]
];