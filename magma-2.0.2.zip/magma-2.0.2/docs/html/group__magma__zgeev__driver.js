var group__magma__zgeev__driver =
[
    [ "magma_zgeev", "group__magma__zgeev__driver.html#gab62fcecc19de68e6ad9d9822b16006eb", null ],
    [ "magma_zgeev_m", "group__magma__zgeev__driver.html#ga8619c8e8766deb37b20b72ef997ce1cc", null ]
];