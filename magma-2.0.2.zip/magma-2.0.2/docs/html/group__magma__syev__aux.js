var group__magma__syev__aux =
[
    [ "single precision", "group__magma__ssyev__aux.html", "group__magma__ssyev__aux" ],
    [ "double precision", "group__magma__dsyev__aux.html", "group__magma__dsyev__aux" ],
    [ "single-complex precision", "group__magma__cheev__aux.html", "group__magma__cheev__aux" ],
    [ "double-complex precision", "group__magma__zheev__aux.html", "group__magma__zheev__aux" ]
];