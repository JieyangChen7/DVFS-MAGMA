var group__magma__cheev__driver =
[
    [ "magma_cheevd", "group__magma__cheev__driver.html#gabc931495efd94b297c02e9266c14b564", null ],
    [ "magma_cheevd_gpu", "group__magma__cheev__driver.html#gae8eb14e95ecbd97680a9c92ca3224261", null ],
    [ "magma_cheevd_m", "group__magma__cheev__driver.html#ga6a523bdb620a159f05fb02f2b4a8b60d", null ],
    [ "magma_cheevdx", "group__magma__cheev__driver.html#ga8e4b2fcaa99be73fb9133c045a1484bb", null ],
    [ "magma_cheevdx_gpu", "group__magma__cheev__driver.html#ga52195b8ae6aee59c7f28ab5250a4dc40", null ],
    [ "magma_cheevdx_m", "group__magma__cheev__driver.html#gaa933a37fcee05ac4b2d40ccb441932bb", null ],
    [ "magma_cheevr", "group__magma__cheev__driver.html#ga427148c2a7f614ca5a20f9e589caf2c6", null ],
    [ "magma_cheevr_gpu", "group__magma__cheev__driver.html#ga6102f90daa41c8f7775ac9a7c6bfe756", null ],
    [ "magma_cheevx", "group__magma__cheev__driver.html#ga6e46ed340a7fc9a9e0e195001d8b6b22", null ],
    [ "magma_cheevx_gpu", "group__magma__cheev__driver.html#ga0897e30f7b23acc56dbd7160e105def0", null ]
];