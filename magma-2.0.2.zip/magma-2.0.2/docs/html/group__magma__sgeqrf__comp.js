var group__magma__sgeqrf__comp =
[
    [ "magma_sgegqr_gpu", "group__magma__sgeqrf__comp.html#gafcfd2327b9c90c250d36347da25f82d6", null ],
    [ "magma_sgeqrf", "group__magma__sgeqrf__comp.html#ga67f1069095618d37cf029fb42df81c9a", null ],
    [ "magma_sgeqrf2_gpu", "group__magma__sgeqrf__comp.html#gaaf8f8b0714187c11238838a453e8ffce", null ],
    [ "magma_sgeqrf2_mgpu", "group__magma__sgeqrf__comp.html#ga7f7f0c70962196fb23b13fec689f170c", null ],
    [ "magma_sgeqrf3_gpu", "group__magma__sgeqrf__comp.html#gab3ec9c09de0c6f00672558679d3bdd46", null ],
    [ "magma_sgeqrf_batched", "group__magma__sgeqrf__comp.html#ga459682a2d4c7301eb53c185ef84486f0", null ],
    [ "magma_sgeqrf_expert_batched", "group__magma__sgeqrf__comp.html#ga18fd3ce91cc633b1769078bddb6da3b8", null ],
    [ "magma_sgeqrf_gpu", "group__magma__sgeqrf__comp.html#ga41684700fac79d382fa445259e161a9e", null ],
    [ "magma_sgeqrf_m", "group__magma__sgeqrf__comp.html#ga3e69f8d8c24bc3130c01e03af6f658aa", null ],
    [ "magma_sgeqrf_ooc", "group__magma__sgeqrf__comp.html#gaf368019e6d7bdb84fdba1e97452a3b58", null ],
    [ "magma_sorgqr", "group__magma__sgeqrf__comp.html#ga4adecc3bd7162c443584833bb7d2f4c2", null ],
    [ "magma_sorgqr2", "group__magma__sgeqrf__comp.html#ga430ab583a760d099960d921673036d4a", null ],
    [ "magma_sorgqr_gpu", "group__magma__sgeqrf__comp.html#ga841fa19d118d6bea73147290d412076b", null ],
    [ "magma_sorgqr_m", "group__magma__sgeqrf__comp.html#ga6c6d586e88a2dc535e4b152e97c29310", null ],
    [ "magma_sormqr", "group__magma__sgeqrf__comp.html#gac0f5c030789f0e1645b75efcb8e37096", null ],
    [ "magma_sormqr2_gpu", "group__magma__sgeqrf__comp.html#gaf0ab032dc9c089e54b1b9aa1779f7961", null ],
    [ "magma_sormqr_gpu", "group__magma__sgeqrf__comp.html#ga4e7c61a1b509da9b09736163410525a8", null ],
    [ "magma_sormqr_m", "group__magma__sgeqrf__comp.html#ga2dbbb86d1e21d333639e8d3a7755f996", null ]
];