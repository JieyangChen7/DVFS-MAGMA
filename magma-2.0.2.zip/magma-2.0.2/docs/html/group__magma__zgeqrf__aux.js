var group__magma__zgeqrf__aux =
[
    [ "magma_zgeqr2_gpu", "group__magma__zgeqrf__aux.html#gaf46c0d9c726ac8da091f8ba1c1216583", null ],
    [ "magma_zgeqr2x2_gpu", "group__magma__zgeqrf__aux.html#gaf5326ae062babd68066d9f731e4f2d95", null ],
    [ "magma_zgeqr2x3_gpu", "group__magma__zgeqrf__aux.html#gafef65136bc90963ef949842320fd53f0", null ],
    [ "magma_zgeqr2x_gpu", "group__magma__zgeqrf__aux.html#ga0652a2fd35f57b32f022d1cc9d542a1a", null ]
];