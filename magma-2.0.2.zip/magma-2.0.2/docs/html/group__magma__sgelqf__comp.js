var group__magma__sgelqf__comp =
[
    [ "magma_sgelqf", "group__magma__sgelqf__comp.html#ga316add463c87ac2f13e6c110ed8a0798", null ],
    [ "magma_sgelqf_gpu", "group__magma__sgelqf__comp.html#ga015b4fe33f374f5dda5d47198569d434", null ],
    [ "magma_sorglq", "group__magma__sgelqf__comp.html#ga282c24919cb98270c7db193daf802c8d", null ],
    [ "magma_sormlq", "group__magma__sgelqf__comp.html#ga17e6ebb7ba09828569897e5a7207a444", null ]
];