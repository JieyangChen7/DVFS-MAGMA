var group__magma__dgeqrf__comp =
[
    [ "magma_dgegqr_gpu", "group__magma__dgeqrf__comp.html#ga0376527df86ce873c540bd217cb0a50a", null ],
    [ "magma_dgeqrf", "group__magma__dgeqrf__comp.html#ga472ce8a0ffb5cfdaa1d84b356671adb7", null ],
    [ "magma_dgeqrf2_gpu", "group__magma__dgeqrf__comp.html#ga6998f468207dbed0239ebcfa5f110f8e", null ],
    [ "magma_dgeqrf2_mgpu", "group__magma__dgeqrf__comp.html#gad05542d08a26832ae15510fc5cc46fab", null ],
    [ "magma_dgeqrf3_gpu", "group__magma__dgeqrf__comp.html#gad8eaeb131d5bb14f7f60320081f4d071", null ],
    [ "magma_dgeqrf_batched", "group__magma__dgeqrf__comp.html#ga40a3d0b56da775bc46dda24b161221d5", null ],
    [ "magma_dgeqrf_expert_batched", "group__magma__dgeqrf__comp.html#ga5e38a1942bf332d7c269f2d30db340ed", null ],
    [ "magma_dgeqrf_gpu", "group__magma__dgeqrf__comp.html#ga20a025e45c396f28377f49be9616f31d", null ],
    [ "magma_dgeqrf_m", "group__magma__dgeqrf__comp.html#ga03b0d6f98516f806c0f2e635c2accbf2", null ],
    [ "magma_dgeqrf_ooc", "group__magma__dgeqrf__comp.html#ga48c9f101bd7829be09b425baadde3ee1", null ],
    [ "magma_dorgqr", "group__magma__dgeqrf__comp.html#ga09f0829a12ccf16d66983440f47f35dd", null ],
    [ "magma_dorgqr2", "group__magma__dgeqrf__comp.html#ga533c1e3a356b9ad35a73d4e01f0d23fb", null ],
    [ "magma_dorgqr_gpu", "group__magma__dgeqrf__comp.html#gaed34f29547a25016b378df030b54ad2e", null ],
    [ "magma_dorgqr_m", "group__magma__dgeqrf__comp.html#gae1ecb5966c9cb28189b88e0dd9b5e3d2", null ],
    [ "magma_dormqr", "group__magma__dgeqrf__comp.html#ga87c875b90a1663dcc8763ba85e284168", null ],
    [ "magma_dormqr2_gpu", "group__magma__dgeqrf__comp.html#gabc3af637b21d3af61bffcb48150b9664", null ],
    [ "magma_dormqr_gpu", "group__magma__dgeqrf__comp.html#gaf4e3140105e61e0d2801181e132e7317", null ],
    [ "magma_dormqr_m", "group__magma__dgeqrf__comp.html#gaeab0c0e7c4bb84fc2e0a2e3572998cf8", null ]
];