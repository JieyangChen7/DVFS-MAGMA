var group__magma__sygv__driver =
[
    [ "single precision", "group__magma__ssygv__driver.html", "group__magma__ssygv__driver" ],
    [ "double precision", "group__magma__dsygv__driver.html", "group__magma__dsygv__driver" ],
    [ "single-complex precision", "group__magma__chegv__driver.html", "group__magma__chegv__driver" ],
    [ "double-complex precision", "group__magma__zhegv__driver.html", "group__magma__zhegv__driver" ]
];