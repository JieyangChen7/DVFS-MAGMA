var group__magma__zposv__aux =
[
    [ "magma_zlauum", "group__magma__zposv__aux.html#ga6eeff9fb7989b4a118c9e1ae7bd7c29e", null ],
    [ "magma_zlauum_gpu", "group__magma__zposv__aux.html#gab60622fd1a62e473c9e6c2c03001aa58", null ]
];