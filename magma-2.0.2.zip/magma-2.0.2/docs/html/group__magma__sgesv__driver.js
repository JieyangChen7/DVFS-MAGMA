var group__magma__sgesv__driver =
[
    [ "magma_sgesv", "group__magma__sgesv__driver.html#ga2d71f75089cff433b14ea514e5bec68b", null ],
    [ "magma_sgesv_batched", "group__magma__sgesv__driver.html#ga2b96eca545ce793500e02d6b7d84bbfc", null ],
    [ "magma_sgesv_gpu", "group__magma__sgesv__driver.html#gad9fdef0ee848a448e18b811f880b91bb", null ],
    [ "magma_sgesv_nopiv_batched", "group__magma__sgesv__driver.html#gada0339b5943fca6e4b9a324d618ad1a4", null ],
    [ "magma_sgesv_nopiv_gpu", "group__magma__sgesv__driver.html#gacf27e06d774ef649633976b54fee06f4", null ],
    [ "magma_sgesv_rbt", "group__magma__sgesv__driver.html#gafe268a92a7065c1c179d3a45e83e2c0d", null ],
    [ "magma_sgesv_rbt_batched", "group__magma__sgesv__driver.html#ga4bc872e52496594c42efdfb65c88789e", null ]
];