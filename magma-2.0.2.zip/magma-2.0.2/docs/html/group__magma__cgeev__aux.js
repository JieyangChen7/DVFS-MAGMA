var group__magma__cgeev__aux =
[
    [ "magma_clahr2", "group__magma__cgeev__aux.html#gaefcf5cb100c3c002cafa081b269404d8", null ],
    [ "magma_clahr2_m", "group__magma__cgeev__aux.html#gac08ca4a4933b6e5f61d23deb6029c183", null ],
    [ "magma_clahru", "group__magma__cgeev__aux.html#ga326d6d68dabc51ad86889663d67b6937", null ],
    [ "magma_clahru_m", "group__magma__cgeev__aux.html#gafd84ca7a226016632592402d5928a5f2", null ],
    [ "magma_clatrsd", "group__magma__cgeev__aux.html#gacf80ff653a47cac6a90f7bac4eaa3197", null ]
];