var group__magma__zhesv__driver =
[
    [ "magma_zhesv", "group__magma__zhesv__driver.html#gacc811e6871c6130f175f8abe53ad7aa2", null ],
    [ "magma_zhesv_nopiv_gpu", "group__magma__zhesv__driver.html#gad92c4449a66a3f2cb59017d2f5010512", null ]
];