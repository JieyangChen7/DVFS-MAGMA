var group__magma__gesv__driver =
[
    [ "single precision", "group__magma__sgesv__driver.html", "group__magma__sgesv__driver" ],
    [ "double precision", "group__magma__dgesv__driver.html", "group__magma__dgesv__driver" ],
    [ "single-complex precision", "group__magma__cgesv__driver.html", "group__magma__cgesv__driver" ],
    [ "double-complex precision", "group__magma__zgesv__driver.html", "group__magma__zgesv__driver" ]
];