var group__magma__dgeqrf__aux =
[
    [ "magma_dgeqr2_gpu", "group__magma__dgeqrf__aux.html#gaa2ad4b5e3d8e59f18541fc3b8fd51bd2", null ],
    [ "magma_dgeqr2x2_gpu", "group__magma__dgeqrf__aux.html#ga806641cdc48e95759e2b35f81c722630", null ],
    [ "magma_dgeqr2x3_gpu", "group__magma__dgeqrf__aux.html#ga4615e017d8e9ec150919b8cd560e006e", null ],
    [ "magma_dgeqr2x_gpu", "group__magma__dgeqrf__aux.html#ga526015d27706d590f221a7535a32cf97", null ]
];