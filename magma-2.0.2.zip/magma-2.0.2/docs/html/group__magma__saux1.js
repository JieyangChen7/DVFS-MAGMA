var group__magma__saux1 =
[
    [ "magma_slarfg_gpu", "group__magma__saux1.html#ga68f3876ea2ad0b81ad7dc345c472d104", null ],
    [ "magma_slarfgtx_gpu", "group__magma__saux1.html#gabdee1f1e61ebb23ea9c0d07a37f61c2f", null ],
    [ "magma_slarfgx_gpu", "group__magma__saux1.html#gaea80736b3f038a358e2dd264c4494e3b", null ],
    [ "magma_slarfx_gpu", "group__magma__saux1.html#ga1b8450be223366d1a981ba3eef189702", null ],
    [ "magmablas_slarfg", "group__magma__saux1.html#gaa893a15a26ecbe0c46c32c929968c272", null ]
];