var group__magma__chesv__driver =
[
    [ "magma_chesv", "group__magma__chesv__driver.html#gad8b3e0e3a588bb54e691ed75419f0a2a", null ],
    [ "magma_chesv_nopiv_gpu", "group__magma__chesv__driver.html#gaf9fe1185517f6d4f53f1d6e90b248445", null ]
];