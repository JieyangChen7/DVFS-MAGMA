var group__magma__geev =
[
    [ "Non-symmetric eigenvalue: driver", "group__magma__geev__driver.html", "group__magma__geev__driver" ],
    [ "Non-symmetric eigenvalue: computational", "group__magma__geev__comp.html", "group__magma__geev__comp" ],
    [ "Non-symmetric eigenvalue: auxiliary", "group__magma__geev__aux.html", "group__magma__geev__aux" ]
];