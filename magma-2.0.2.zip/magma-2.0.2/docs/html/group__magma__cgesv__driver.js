var group__magma__cgesv__driver =
[
    [ "magma_cgesv", "group__magma__cgesv__driver.html#ga9c287ca219a3219a8e53795ecd29de48", null ],
    [ "magma_cgesv_batched", "group__magma__cgesv__driver.html#gaf28ce81b96c7a292da2bedb690531ced", null ],
    [ "magma_cgesv_gpu", "group__magma__cgesv__driver.html#ga34f671651bbadf0bc280e2f8c9f5635e", null ],
    [ "magma_cgesv_nopiv_batched", "group__magma__cgesv__driver.html#ga850dcda03e95e308f72ad91a9f370a32", null ],
    [ "magma_cgesv_nopiv_gpu", "group__magma__cgesv__driver.html#ga38e06206e88bbd03b0b775d47c1309c9", null ],
    [ "magma_cgesv_rbt", "group__magma__cgesv__driver.html#ga14b973e3780a2f801b6547d8d89499bc", null ],
    [ "magma_cgesv_rbt_batched", "group__magma__cgesv__driver.html#ga83e03bcc3dd84ff11b739e36469983d5", null ]
];