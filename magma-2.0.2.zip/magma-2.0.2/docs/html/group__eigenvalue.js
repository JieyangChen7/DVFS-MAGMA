var group__eigenvalue =
[
    [ "Non-symmetric eigenvalue", "group__magma__geev.html", "group__magma__geev" ],
    [ "Symmetric eigenvalue", "group__magma__syev.html", "group__magma__syev" ]
];