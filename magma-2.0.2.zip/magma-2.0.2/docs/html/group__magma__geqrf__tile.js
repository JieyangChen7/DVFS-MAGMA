var group__magma__geqrf__tile =
[
    [ "single precision", "group__magma__sgeqrf__tile.html", null ],
    [ "double precision", "group__magma__dgeqrf__tile.html", null ],
    [ "single-complex precision", "group__magma__cgeqrf__tile.html", null ],
    [ "double-complex precision", "group__magma__zgeqrf__tile.html", null ]
];