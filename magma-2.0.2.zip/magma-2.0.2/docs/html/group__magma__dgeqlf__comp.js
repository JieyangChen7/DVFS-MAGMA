var group__magma__dgeqlf__comp =
[
    [ "magma_dgeqlf", "group__magma__dgeqlf__comp.html#ga2b3743b31af115045246faebdd7ded9f", null ],
    [ "magma_dormql", "group__magma__dgeqlf__comp.html#gad832965677feb9c09dec834f29b9f8b4", null ],
    [ "magma_dormql2_gpu", "group__magma__dgeqlf__comp.html#gaf10a2bd9285523545602e3f4157b960e", null ]
];