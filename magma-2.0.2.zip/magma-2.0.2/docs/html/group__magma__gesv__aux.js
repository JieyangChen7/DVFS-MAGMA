var group__magma__gesv__aux =
[
    [ "single precision", "group__magma__sgesv__aux.html", "group__magma__sgesv__aux" ],
    [ "double precision", "group__magma__dgesv__aux.html", "group__magma__dgesv__aux" ],
    [ "single-complex precision", "group__magma__cgesv__aux.html", "group__magma__cgesv__aux" ],
    [ "double-complex precision", "group__magma__zgesv__aux.html", "group__magma__zgesv__aux" ]
];