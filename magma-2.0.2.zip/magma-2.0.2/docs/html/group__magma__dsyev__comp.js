var group__magma__dsyev__comp =
[
    [ "magma_dorgtr", "group__magma__dsyev__comp.html#gaba9eb3b3ba9aad7e64baac4d4de1014e", null ],
    [ "magma_dormtr", "group__magma__dsyev__comp.html#ga829949906bb96858703e9af38abe4d4f", null ],
    [ "magma_dormtr_gpu", "group__magma__dsyev__comp.html#gaa284c0ed78b637e3c25352076fcf94dd", null ],
    [ "magma_dormtr_m", "group__magma__dsyev__comp.html#ga9b28a09e3245a7f31f1b4040007bfbc3", null ],
    [ "magma_dstedx", "group__magma__dsyev__comp.html#ga894ce156db4fe17a0997135548f3db20", null ],
    [ "magma_dstedx_m", "group__magma__dsyev__comp.html#ga7a2db17db761047f9a4f32e57c9c21df", null ],
    [ "magma_dsygst", "group__magma__dsyev__comp.html#ga9490b0e0440579cc806c5070a4c605df", null ],
    [ "magma_dsygst_gpu", "group__magma__dsyev__comp.html#gaf45b316945b2380df5926d50b45d79b1", null ],
    [ "magma_dsygst_m", "group__magma__dsyev__comp.html#ga744698b0b1b1d5cb435329470277cdc4", null ],
    [ "magma_dsytrd", "group__magma__dsyev__comp.html#ga46c485cec62267b9f24ffc3eb4305c69", null ],
    [ "magma_dsytrd2_gpu", "group__magma__dsyev__comp.html#ga469e5eaf8b36af0c936ef130e54e6d04", null ],
    [ "magma_dsytrd_gpu", "group__magma__dsyev__comp.html#ga410f2d73b15e9b75dd16c2da91e9a4be", null ],
    [ "magma_dsytrd_mgpu", "group__magma__dsyev__comp.html#ga12c2cfab95004950c4f37d9da5a8f512", null ]
];