var group__magma__syev__driver =
[
    [ "single precision", "group__magma__ssyev__driver.html", "group__magma__ssyev__driver" ],
    [ "double precision", "group__magma__dsyev__driver.html", "group__magma__dsyev__driver" ],
    [ "single-complex precision", "group__magma__cheev__driver.html", "group__magma__cheev__driver" ],
    [ "double-complex precision", "group__magma__zheev__driver.html", "group__magma__zheev__driver" ]
];