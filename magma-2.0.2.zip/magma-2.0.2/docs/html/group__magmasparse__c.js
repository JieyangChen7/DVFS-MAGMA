var group__magmasparse__c =
[
    [ "magma_cjacobiiter", "group__magmasparse__c.html#gae40ddd9ebda49596d16d8fe8f1f51b55", null ],
    [ "magma_cjacobiiter_precond", "group__magmasparse__c.html#gaa89278186039fe3fdc4b0c23cfce6270", null ],
    [ "magma_cjacobiiter_sys", "group__magmasparse__c.html#gaccffa5ae76ea280ba3e94fbb8179688c", null ],
    [ "magma_cjacobisetup", "group__magmasparse__c.html#gab8bb4241a293868648fff138a796e8d3", null ],
    [ "magma_cjacobisetup_diagscal", "group__magmasparse__c.html#ga6dc5164ee56d8cf0de62b86ef3e3f0aa", null ],
    [ "magma_cjacobisetup_matrix", "group__magmasparse__c.html#ga375db6a67df525e9ffbb7c9c835f09f2", null ],
    [ "magma_cjacobisetup_vector", "group__magmasparse__c.html#ga03871a3f8d695a1fd6de74738e342723", null ]
];