var group__magma__geqrf__aux =
[
    [ "single precision", "group__magma__sgeqrf__aux.html", "group__magma__sgeqrf__aux" ],
    [ "double precision", "group__magma__dgeqrf__aux.html", "group__magma__dgeqrf__aux" ],
    [ "single-complex precision", "group__magma__cgeqrf__aux.html", "group__magma__cgeqrf__aux" ],
    [ "double-complex precision", "group__magma__zgeqrf__aux.html", "group__magma__zgeqrf__aux" ]
];