var group__magma__sgesvd__aux =
[
    [ "magma_slabrd_gpu", "group__magma__sgesvd__aux.html#ga5256589e10dd93362c277902883428b2", null ]
];