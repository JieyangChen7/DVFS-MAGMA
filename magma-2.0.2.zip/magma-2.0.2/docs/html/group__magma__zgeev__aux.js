var group__magma__zgeev__aux =
[
    [ "magma_zlahr2", "group__magma__zgeev__aux.html#ga4957106785c0f1c3a84cbc296f6f3436", null ],
    [ "magma_zlahr2_m", "group__magma__zgeev__aux.html#gac75ef7e3b5157a20e22f0617e8b3e55e", null ],
    [ "magma_zlahru", "group__magma__zgeev__aux.html#ga8cc55af99719fab4bf97c93c4cfb62f6", null ],
    [ "magma_zlahru_m", "group__magma__zgeev__aux.html#ga2e8e876ddf0355e00063ec3df106eb91", null ],
    [ "magma_zlatrsd", "group__magma__zgeev__aux.html#gadd87b3c554d581fe846ebe390661dc4b", null ]
];