var group__magma__sgeev__aux =
[
    [ "magma_slahr2", "group__magma__sgeev__aux.html#ga88eeccc9e2615452029e14d1c7716f1f", null ],
    [ "magma_slahr2_m", "group__magma__sgeev__aux.html#ga08e96428de2e63d49d29bbbf2324dff4", null ],
    [ "magma_slahru", "group__magma__sgeev__aux.html#gafb17313373a656d1316f2d1fcc39d31e", null ],
    [ "magma_slahru_m", "group__magma__sgeev__aux.html#ga71cba043adcb464ba130a8f249d27268", null ],
    [ "magma_slaqtrsd", "group__magma__sgeev__aux.html#ga9da2eeaaaf0396e82d2561db3b9a10a4", null ]
];