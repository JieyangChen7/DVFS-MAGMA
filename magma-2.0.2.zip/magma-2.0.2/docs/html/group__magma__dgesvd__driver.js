var group__magma__dgesvd__driver =
[
    [ "magma_dgesdd", "group__magma__dgesvd__driver.html#ga6ac1524e23541c747ef0a319fde3af2f", null ],
    [ "magma_dgesvd", "group__magma__dgesvd__driver.html#gae96893c07d98c00aa2dad4afc76c89f7", null ]
];