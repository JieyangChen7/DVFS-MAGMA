var group__magma__cgeev__driver =
[
    [ "magma_cgeev", "group__magma__cgeev__driver.html#ga66e094132924aee66e6c08534c9707a4", null ],
    [ "magma_cgeev_m", "group__magma__cgeev__driver.html#gaffda4c5c819c6e973a68c2362e13ffe1", null ]
];