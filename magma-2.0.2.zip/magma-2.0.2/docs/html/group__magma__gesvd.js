var group__magma__gesvd =
[
    [ "SVD: driver", "group__magma__gesvd__driver.html", "group__magma__gesvd__driver" ],
    [ "SVD: computational", "group__magma__gesvd__comp.html", "group__magma__gesvd__comp" ],
    [ "SVD: auxiliary", "group__magma__gesvd__aux.html", "group__magma__gesvd__aux" ]
];