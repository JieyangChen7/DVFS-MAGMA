var group__magma__zaux0 =
[
    [ "magma_zsqrt", "group__magma__zaux0.html#ga167b9ee43c70b4a0c39462c0add4ed04", null ]
];