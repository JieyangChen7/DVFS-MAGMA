var group__magma__geqrf__comp =
[
    [ "single precision", "group__magma__sgeqrf__comp.html", "group__magma__sgeqrf__comp" ],
    [ "double precision", "group__magma__dgeqrf__comp.html", "group__magma__dgeqrf__comp" ],
    [ "single-complex precision", "group__magma__cgeqrf__comp.html", "group__magma__cgeqrf__comp" ],
    [ "double-complex precision", "group__magma__zgeqrf__comp.html", "group__magma__zgeqrf__comp" ]
];