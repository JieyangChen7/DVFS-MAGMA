var group__magma__aux1 =
[
    [ "single precision", "group__magma__saux1.html", "group__magma__saux1" ],
    [ "double precision", "group__magma__daux1.html", "group__magma__daux1" ],
    [ "single-complex precision", "group__magma__caux1.html", "group__magma__caux1" ],
    [ "double-complex precision", "group__magma__zaux1.html", "group__magma__zaux1" ]
];